# -*- coding: utf-8 -*-
"""Focused implementation tests. Synthetic arrays are test-only fixtures.

Do not publish smoke-test outputs as empirical experiment measurements.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'02_code'))
sys.path.insert(0, str(ROOT/'01_data'))
from cloud_features import reverse_cloud
from models import SVMCascade, build_attention_bilstm, build_sequence_baseline, _torch
from train import rolling_cloud, standardize, train_backbone


class TestMethods(unittest.TestCase):
    def test_cloud_equation_known(self):
        ex, en, he = reverse_cloud(np.array([1.,2.,3.,4.]))
        self.assertAlmostEqual(ex,2.5)
        self.assertAlmostEqual(en, np.sqrt(np.pi/2)*1.)
        self.assertAlmostEqual(he, np.sqrt(max(1.66666667-en*en,0)),places=6)

    def test_cloud_first_step_finite(self):
        X = np.arange(2*8*9,dtype=np.float32).reshape(2,8,9)/20
        z=rolling_cloud(X)
        self.assertEqual(z.shape,(2,8,27))
        self.assertTrue(np.isfinite(z).all())
        np.testing.assert_allclose(z[:,0,0::3],X[:,0,:])
        np.testing.assert_allclose(z[:,0,1::3],0)
        np.testing.assert_allclose(z[:,0,2::3],0)

    def test_backbone_and_softmax_shapes(self):
        torch,nn=_torch()
        x=torch.randn(6,8,27)
        for attention in (False,True):
            backbone=build_attention_bilstm(27,use_attention=attention)
            embedding,alpha=backbone(x,return_attn=True)
            self.assertEqual(tuple(embedding.shape),(6,256))
            if attention:
                self.assertEqual(tuple(alpha.shape),(6,8))
                self.assertTrue(torch.allclose(alpha.sum(1),torch.ones(6),atol=1e-5))
            else:
                self.assertIsNone(alpha)
            classifier=nn.Sequential(backbone,nn.Linear(backbone.output_dim,3))
            self.assertEqual(tuple(classifier(x).shape),(6,3))
        for kind,dim in [('lstm',128),('gru',128),('tcn',64)]:
            m=build_sequence_baseline(kind,27)
            self.assertEqual(tuple(m(x).shape),(6,dim))

    def test_tcn_causal(self):
        torch,_=_torch()
        model=build_sequence_baseline('tcn',9)
        model.eval()
        x=torch.randn(3,8,9)
        x2=x.clone()
        x2[:,5:]+=1000
        with torch.no_grad():
            # Causal convolution: early outputs may not depend on future inputs.
            seq=lambda a:model.conv(a.transpose(1,2))
            np.testing.assert_allclose(seq(x)[:,:,:5],seq(x2)[:,:,:5],atol=1e-5,rtol=1e-5)

    def test_ovr_classifiers(self):
        rng=np.random.default_rng(2)
        x=np.concatenate([rng.normal(i,0.2,size=(10,5)) for i in (-2,0,2)])
        y=np.repeat([1,2,3],10)
        cas=SVMCascade(seed=42).fit(x,y)
        self.assertEqual(len(cas.svm.estimators_),3)
        a,m,s,k=cas.predict(x)
        self.assertEqual(len(a),len(y))
        self.assertTrue((m>=0).all())
        p=cas.predict_proba(x)
        self.assertEqual(p.shape,(30,3))
        np.testing.assert_allclose(p.sum(1),1,rtol=1e-6,atol=1e-6)

    def test_real_training_logs_and_checkpoint(self):
        # Test-only randomly generated arrays, never delivered as study results.
        rng=np.random.default_rng(42)
        X=rng.normal(size=(18,8,9)).astype('float32')
        y=np.tile([1,2,3],6)
        fit=np.zeros(len(y),bool);fit[:12]=True
        val=np.zeros(len(y),bool);val[12:]=True
        with tempfile.TemporaryDirectory() as tmp:
            model,backbone,meta=train_backbone('basic_bilstm_svm',X,y,fit,val,1,Path(tmp),epochs=2)
            self.assertEqual(meta['epochs_completed'],2)
            self.assertTrue((Path(tmp)/'basic_bilstm_svm_seed1_checkpoint.pt').exists())
            import pandas as pd
            df=pd.read_csv(Path(tmp)/'basic_bilstm_svm_seed1_epochs.csv')
            self.assertEqual(df.epoch.tolist(),[1,2])
            self.assertTrue(np.isfinite(df.val_loss.to_numpy()).all())
            self.assertTrue(all(len(str(x))>10 for x in df.timestamp_utc))

    def test_archived_paired_arithmetic(self):
        import pandas as pd
        p=pd.read_csv(ROOT/'04_outputs/predictions/paired_window_seed3_1102.csv')
        self.assertEqual(len(p),1102)
        self.assertEqual(len(p.drop_duplicates(['firm_id','win_index'])),1102)
        cols={c.lower():c for c in p.columns}
        # `reconcile_review.py` performs exact per-class and McNemar checks.
        summary=pd.read_csv(ROOT/'04_outputs/tables/table6_seed_reconciliation.csv')
        self.assertEqual(len(summary),5)

    def test_st_long_interval_no_arbitrary_cap(self):
        import pandas as pd
        from build_data import interval_flags
        test = pd.DataFrame([{'Stkcd':'000001','in_date':'2019-01-01',
                              'out_date':'2022-01-01'}])
        flags=interval_flags(test,'in_date','out_date')
        self.assertEqual(len(flags),12)
        self.assertIn(('000001','2021Q4'),flags)
        self.assertNotIn(('000001','2022Q1'),flags)

    def test_source_gate_enforces_full_candidate_coverage(self):
        from source_audit import validate_coverage
        import pandas as pd
        issues=validate_coverage()
        pending=0
        for name in ('commercial_paper_source_review.csv','st_source_review.csv'):
            d=pd.read_csv(ROOT/'01_data'/name)
            pending += int((~d.verification.isin(['CONFIRMED','REJECTED'])).sum())
        self.assertGreaterEqual(len(issues),pending)
        if pending == 0:
            self.assertEqual(issues,[])

    def test_strict_lithium_exposure_uses_no_future_quarters(self):
        import pandas as pd
        from build_data import add_lithium_exposure_causal, build_panel
        panel=build_panel(strict_pit=True)
        self.assertEqual(len(panel),3107)
        self.assertTrue(np.isfinite(panel.lithium_exposure.to_numpy()).all())
        # Full-sample future elasticity must not be injected into 2018.
        earlier=panel[panel.quarter.str.startswith('2018')]
        self.assertTrue(np.allclose(earlier.li_beta.to_numpy(),0))

    def test_historical_log_structure_and_XGB_coverage(self):
        import pandas as pd
        logs=pd.read_csv(ROOT/'04_outputs/tables/tableA2_best_epoch.csv')
        self.assertEqual(len(logs),30)
        self.assertTrue(logs.best_epoch.between(190,199).all())
        pred=pd.read_csv(ROOT/'04_outputs/predictions/predictions_all.csv')
        xgb=pred[pred.model=='XGBoost']
        self.assertEqual(sorted(xgb.seed.unique().tolist()),[1,2,3,4])
        self.assertEqual(len(xgb),4*1102)


if __name__=='__main__':
    unittest.main(verbosity=2)
