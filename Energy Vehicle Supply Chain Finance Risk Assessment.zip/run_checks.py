# -*- coding: utf-8 -*-
"""One-shot entry point of the consistency-verification scripts (result layer).

Runs compute_numbers.py, calibrate_theta.py and 03_figures/make_figures.py in
order, recording the real system time, the runtime environment and the full
standard output in `04_outputs/logs/run_<timestamp>.log`.

Distinction from training logs (important):
  * run_*.log files produced by this script record the real local execution
    time and console output;
  * 04_outputs/predictions/training_log.csv and 04_outputs/logs/training_log_*.csv
    are per-epoch training-loss records without wall-clock timestamps or
    duration columns; see 00_README.md Section 5.

Usage (from the package root):
    python run_checks.py            # run everything
    python run_checks.py --no-fig   # skip figure rendering
"""
from __future__ import annotations

import argparse
import platform
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "04_outputs" / "logs"


class Tee:
    """Write to both the terminal and the log file."""

    def __init__(self, path: Path):
        self.fh = open(path, "w", encoding="utf-8")

    def write(self, s: str) -> None:
        sys.__stdout__.write(s)
        sys.__stdout__.flush()
        self.fh.write(s)
        self.fh.flush()

    def close(self) -> None:
        self.fh.close()


def stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def run(cmd: list[str], tee: Tee, cwd: Path | None = None) -> int:
    tee.write(f"\n$ {' '.join(cmd)}\n  started : {stamp()}\n")
    t0 = time.time()
    p = subprocess.run(cmd, cwd=str(cwd or ROOT), capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    if p.stdout:
        tee.write(p.stdout if p.stdout.endswith("\n") else p.stdout + "\n")
    if p.stderr.strip():
        tee.write("[stderr]\n" + p.stderr)
    tee.write(f"  finished: {stamp()}  (elapsed {time.time() - t0:.2f} s, "
              f"exit code {p.returncode})\n")
    return p.returncode


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-fig", action="store_true", help="skip figure rendering")
    args = ap.parse_args()

    LOGS.mkdir(parents=True, exist_ok=True)
    log_path = LOGS / f"run_{datetime.now().strftime('%Y%m%dT%H%M%S')}.log"
    tee = Tee(log_path)
    tee.write("Package verification run record\n")
    tee.write(f"Start time (local system time): {stamp()}\n")
    tee.write(f"Python     : {sys.version.splitlines()[0]}\n")
    tee.write(f"Executable : {sys.executable}\n")
    tee.write(f"Platform   : {platform.platform()}\n")
    vers = []
    for mod, label in (("numpy", "numpy"), ("pandas", "pandas"),
                       ("scipy", "scipy"), ("sklearn", "scikit-learn")):
        try:
            m = __import__(mod)
            vers.append(f"{label} {getattr(m, '__version__', '?')}")
        except Exception:
            vers.append(f"{label} not installed")
    tee.write(" | ".join(vers) + "\n")
    tee.write(f"Working dir: {ROOT}\n")
    tee.write("=" * 72 + "\n")

    codes = []
    codes.append(("compute_numbers.py", run([sys.executable, "02_code/compute_numbers.py"], tee)))
    codes.append(("reconcile_review.py", run([sys.executable, "02_code/reconcile_review.py"], tee)))
    # WARNING is explicit: the missing official raw-list evidence must not be
    # mistaken for a completed editorial reproducibility audit.
    codes.append(("source_audit.py [informational]",run([sys.executable,"01_data/source_audit.py"],tee)))

    if not args.no_fig:
        codes.append(("make_figures.py", run([sys.executable, "03_figures/make_figures.py"], tee)))
    else:
        tee.write("\n[figures] skipped due to --no-fig.\n")

    codes.append(("calibrate_theta.py", run([sys.executable, "02_code/calibrate_theta.py"], tee)))

    tee.write("\n" + "=" * 72 + "\n")
    tee.write(f"End time (local system time): {stamp()}\n")
    bad = [n for n, c in codes if c != 0]
    tee.write(("Statistical checks finished. OFFICIAL LABEL SOURCE AUDIT IS STILL PENDING.\n"
              if not bad else f"Non-zero exit codes present: {bad}\n"))
    tee.write(f"Run log: {log_path.relative_to(ROOT)}\n")
    tee.close()
    print(f"\nLog written to: {log_path}")
    return 0 if not bad else 1


if __name__ == "__main__":
    raise SystemExit(main())
