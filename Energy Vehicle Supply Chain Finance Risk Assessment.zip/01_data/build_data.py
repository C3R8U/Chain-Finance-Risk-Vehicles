# -*- coding: utf-8 -*-
"""Data construction: open-source extracts -> quarterly panel -> features ->
labels -> sliding windows -> time-forward split.

DEFAULT POLICY: official label reconstruction requires auditable, official ST
and monthly commercial-paper evidence. Use --label-mode legacy ONLY to replay
the supplied historical (not yet source-verified) manuscript snapshot.

Data sources (all open channels, consistent with Section 3.4 of the manuscript):
  - CNEquity local Parquet data lake (01_data/raw/cnequity/, extracted by
    extract_cnequity.py): financial statements, notes, beta, WACC, lithium
    carbonate spot price;
  - AKShare: secondary securities disclosure extraction; the unverified
    historical snapshots stay in raw/akshare/ for replay only.
  - official/ verified records: ST exchange announcements and Shanghai
    Commercial Paper Exchange monthly overdue lists; NOT an AKShare API.

Event interval convention: ST/qualified-opinion/rating statuses are evaluated
as of each actual quarter end: start <= quarter_end < end (left-closed/right-open).
Empty end means active through the end of the sample period; no 4-quarter cap.
Official commercial-paper lists use the actual public release date.

Outputs (all under 01_data/interim/):
    panel_quarterly.csv      firm-quarter panel (all features)
    events.csv               exogenous event detail (firm-quarter-event type)
    label_source.csv         quarterly labels and source events
    windows.csv              per-window records (firm, quarters, label, split)
    window_tensor.npz        window feature tensor + labels + firm groups
    preprocessing_report.md  preprocessing report
    build_manifest.json      row counts and construction parameters

Run: `python build_data.py` (official-evidence gate; fails when pending).
Legacy replay: `python build_data.py --label-mode legacy` (not final labels).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from source_audit import validate as validate_official, validate_coverage
from preprocess import (AUX_FEATURES, FEATURES, QEND, q_index,
                        quarter_range, forward_fill, pit_check, zscore_params,
                        write_report)

PKG = Path(__file__).resolve().parents[1]
DATA_RAW = PKG / "01_data" / "raw"
DATA_CNEQ = DATA_RAW / "cnequity"   # CNEquity data-lake export snapshot
DATA_AK = DATA_RAW / "akshare"     # AKShare public-disclosure export snapshot
DATA_INT = PKG / "01_data" / "interim"
BASE_PRED = PKG / "04_outputs" / "predictions"

START_Q = "2018Q1"
END_Q = "2023Q4"
WINDOW_T = 8
WINDOW_S = 1
TRAIN_END_Q = "2021Q4"
TEST_START_Q = "2022Q1"
RISK_CODE = {"low": 1, "mid": 2, "high": 3}
QUARTERS = quarter_range(START_Q, END_Q)

LINK2SEG = {"Downstream (Vehicle Manufacturing)": "vehicle",
            "Midstream (Power Battery)": "battery",
            "Midstream (Core Components, incl. Upstream Materials)": "components"}

EVENT_HIGH = {"st_flag": "ST/*ST", "audit_qualified": "non-standard audit opinion",
              "commercial_paper_overdue": "commercial paper overdue", "interest_overdue": "interest payment default"}
EVENT_MID = {"rating_downgrade": "rating downgrade", "outlook_negative": "outlook revised to negative",
             "credit_spread_jump": "credit-spread jump", "regulatory_inquiry": "regulatory inquiry"}
SOURCE_PRIORITY = ["st_flag", "audit_qualified", "commercial_paper_overdue",
                   "interest_overdue", "rating_downgrade", "outlook_negative",
                   "credit_spread_jump", "regulatory_inquiry"]
FLAG_COLS = ["st_flag", "audit_qualified", "commercial_paper_overdue",
             "interest_overdue", "rating_downgrade", "outlook_negative",
             "credit_spread_jump", "regulatory_inquiry"]


# ------------------------------------------------------------------ helpers
def _read(path: Path, dtype_str: bool = True) -> pd.DataFrame:
    kw = {"encoding": "utf-8-sig"}
    if dtype_str:
        kw["dtype"] = {"Stkcd": str}
    return pd.read_csv(path, **kw)


def q_of_date(s: str) -> str:
    d = pd.Timestamp(s)
    return f"{d.year}Q{(d.month - 1) // 3 + 1}"


def interval_flags(df: pd.DataFrame, start_col: str, end_col: str) -> set:
    """Mark active status at the ACTUAL quarter-end; no arbitrary 4-quarter cap.

    A published status remains effective from implementation date until, but
    excluding, the published revocation date. Empty end means still active.
    """
    out = set()
    for r in df.itertuples():
        start = pd.Timestamp(getattr(r, start_col))
        end_raw = getattr(r, end_col)
        end = pd.Timestamp(end_raw) if isinstance(end_raw, str) and end_raw else None
        for q in QUARTERS:
            qend = pd.Timestamp(QEND[q])
            if qend >= start and (end is None or qend < end):
                out.add((r.Stkcd, q))
    return out


# ------------------------------------------------------------------ panel
def build_panel(*, strict_pit: bool = False) -> pd.DataFrame:
    fin = _read(DATA_CNEQ / "financial_statement_items.csv")
    fin["quarter"] = fin.report_period.map(q_of_date)
    fin = fin[fin.quarter.isin(QUARTERS)].copy()

    panel = fin[["Stkcd", "quarter", "ann_date", "report_period"]].copy()
    panel["lev"] = fin.total_liab / fin.total_assets
    panel["debt_equity"] = fin.total_liab / fin.total_equity
    panel["current_ratio"] = fin.total_current_assets / fin.total_current_liab
    panel["quick_ratio"] = (fin.total_current_assets - fin.inventory) / fin.total_current_liab
    panel["interest_cover"] = fin.ebit / fin.interest_expense.replace(0, np.nan)
    panel["ocf_to_cl"] = fin.net_cash_operating / fin.total_current_liab
    panel["gross_margin"] = (fin.revenue - fin.cost_of_sales) / fin.revenue.replace(0, np.nan)
    panel["raw_material_share"] = _ratio_with(
        DATA_CNEQ / "notes_cost_structure.csv", "raw_material_cost",
        fin.set_index(["Stkcd", "quarter"]).cost_of_sales)
    panel["gov_subsidy_ratio"] = _ratio_with(
        DATA_CNEQ / "notes_gov_subsidy.csv", "gov_subsidy",
        fin.set_index(["Stkcd", "quarter"]).revenue)
    panel["warranty_ratio"] = _ratio_with(
        DATA_CNEQ / "notes_warranty_provision.csv", "warranty_provision",
        fin.set_index(["Stkcd", "quarter"]).cost_of_sales)

    beta = _read(DATA_CNEQ / "beta_quarterly.csv")[["Stkcd", "quarter", "beta"]]
    wacc = _read(DATA_CNEQ / "wacc_quarterly.csv")[["Stkcd", "quarter", "wacc"]]
    panel = panel.merge(beta, on=["Stkcd", "quarter"], how="left")
    panel = panel.merge(wacc, on=["Stkcd", "quarter"], how="left")

    panel["quarter_idx"] = panel.quarter.map(q_index)
    panel = panel.sort_values(["Stkcd", "quarter_idx"]).reset_index(drop=True)
    panel = (add_lithium_exposure_causal(panel) if strict_pit
             else add_lithium_exposure(panel))
    panel = pit_check(panel)
    # forward-fill only within the valid panel (time causality)
    panel[FORWARD_FILL_COLS] = panel.groupby("Stkcd")[FORWARD_FILL_COLS].ffill()
    return panel


def _ratio_with(note_file: Path, val_col: str, base: pd.Series) -> pd.Series:
    """Note amount / statement denominator aligned on the (Stkcd, quarter) key."""
    note = _read(note_file)
    note["quarter"] = note.report_period.map(q_of_date)
    nv = note.set_index(["Stkcd", "quarter"])[val_col]
    vals = []
    for k, b in base.items():
        v = nv.get(k, np.nan)
        vals.append(v / b if (pd.notna(v) and b) else np.nan)
    # base follows panel row order; return an array to avoid index-alignment issues
    return np.asarray(vals, dtype=float)


def add_lithium_exposure(panel: pd.DataFrame) -> pd.DataFrame:
    """Lithium exposure = raw-material share x elasticity of gross margin to
    log lithium-price changes.

    The elasticity is estimated by OLS on at least 8 quarters of observations
    preceding the current period; the segment median substitutes when the
    history is insufficient. Only current and past information is used
    (point-in-time) throughout.
    """
    li = _read(DATA_CNEQ / "lithium_price.csv", dtype_str=False)
    li["dlnP"] = np.log(li.lithium_price).diff()
    dlnp = dict(zip(li.quarter, li.dlnP))
    panel["dlnP"] = panel.quarter.map(dlnp)
    panel = panel.sort_values(["Stkcd", "quarter_idx"])

    firm_meta = _read(DATA_INT / "firm_meta.csv")
    seg_of = dict(zip(firm_meta.Stkcd, firm_meta.Industry_Chain_Link.map(LINK2SEG)))

    out = []
    for stk, g in panel.groupby("Stkcd", sort=False):
        g = g.sort_values("quarter_idx").copy()
        g["gm_change"] = g.gross_margin.diff()
        x_all = g.dlnP.shift(1).to_numpy()
        y_all = g.gm_change.shift(1).to_numpy()
        ok = ~np.isnan(x_all) & ~np.isnan(y_all)
        beta_i = np.nan
        if ok.sum() >= 8:
            x, y = x_all[ok], y_all[ok]
            vx = float(np.var(x, ddof=1))
            if vx > 0:
                beta_i = float(np.cov(x, y, ddof=1)[0, 1] / vx)
        g["li_beta"] = beta_i
        g["segment"] = seg_of.get(stk, "components")
        out.append(g)
    panel = pd.concat(out, ignore_index=True)
    med = panel.groupby("segment").li_beta.transform("median")
    panel["li_beta"] = panel.li_beta.fillna(med)
    panel["lithium_exposure"] = panel.raw_material_share * panel.li_beta
    return panel.drop(columns=["gm_change", "dlnP"])


def add_lithium_exposure_causal(panel: pd.DataFrame) -> pd.DataFrame:
    """Point-in-time quarterly elasticity; never fit on later-quarter data.

    In quarter t, estimate Cov(Delta log P, Delta margin)/Var(Delta log P)
    from up to all strictly earlier quarters with at least eight valid pairs.
    An unidentifiable early-period elasticity is explicitly set to zero; it
    is not silently imputed from future years or future firms in the segment.
    """
    li = _read(DATA_CNEQ / 'lithium_price.csv', dtype_str=False)
    li = li.sort_values('quarter', key=lambda v: v.map(q_index))
    li['dlnP'] = np.log(li.lithium_price).diff()
    prices = dict(zip(li.quarter, li.dlnP))
    output=[]
    for stk,g in panel.groupby('Stkcd',sort=False):
        g=g.sort_values('quarter_idx').copy()
        dp=g.quarter.map(prices).to_numpy(dtype=float)
        dm=g.gross_margin.diff().to_numpy(dtype=float)
        estimated=[]
        for k in range(len(g)):
            # Historical observations only: index k is never included in fit.
            x,y=dp[:k],dm[:k]
            good=np.isfinite(x)&np.isfinite(y)
            if good.sum()<8 or np.var(x[good],ddof=1)<1e-14:
                estimated.append(0.0)
            else:
                estimated.append(float(np.cov(x[good],y[good],ddof=1)[0,1]/
                                       np.var(x[good],ddof=1)))
        g['li_beta']=estimated
        g['lithium_exposure']=g.raw_material_share*g.li_beta
        output.append(g)
    return pd.concat(output,ignore_index=True)


FORWARD_FILL_COLS = FEATURES + AUX_FEATURES


# ------------------------------------------------------------------ events
def build_events(label_mode="legacy") -> pd.DataFrame:
    """Reconstruct event flags; verified CPO uses official publication dates."""
    firm_meta = _read(DATA_INT / "firm_meta.csv")
    stks = firm_meta.Stkcd.tolist()
    grid = pd.MultiIndex.from_product([stks, QUARTERS],
                                      names=["Stkcd", "quarter"]).to_frame(index=False)

    def add_flag(frames: list[set], col: str) -> None:
        s = set().union(*frames) if frames else set()
        grid[col] = [1 if (s, q) in s else 0 for s, q in zip(grid.Stkcd, grid.quarter)]

    if label_mode == "verified":
        st = validate_official('st_status_verified.csv')
        cpo = validate_official('commercial_paper_verified.csv')
        cpo = cpo.copy()
        # A list referring to an earlier month cannot be used in a quarter
        # earlier than the official publication of that list.
        cpo['quarter'] = cpo['publication_date'].map(q_of_date)
        # The strict ledger has already been source-checked (local file+SHA256).
    elif label_mode == "legacy":
        st = _read(DATA_AK / "st_status.csv")
        cpo = _read(DATA_AK / "commercial_paper_overdue.csv")
    else:
        raise ValueError('label_mode must be verified or legacy')
    aud = _read(DATA_AK / "audit_opinion.csv")
    dft = _read(DATA_AK / "bond_interest_default.csv")
    rat = _read(DATA_AK / "bond_rating_change.csv")
    inq = _read(DATA_AK / "regulatory_inquiry.csv")

    st_set = interval_flags(st, "in_date", "out_date")
    aud_set = interval_flags(aud, "ann_date", "clearance_date")
    rat_dn = interval_flags(rat[rat.direction == "rating downgrade"], "ann_date", "effect_until")
    rat_ol = interval_flags(rat[rat.direction == "outlook revised to negative"], "ann_date", "effect_until")
    inq_set = interval_flags(inq, "letter_date", "reply_date")

    grid["st_flag"] = [1 if (s, q) in st_set else 0 for s, q in zip(grid.Stkcd, grid.quarter)]
    grid["audit_qualified"] = [1 if (s, q) in aud_set else 0 for s, q in zip(grid.Stkcd, grid.quarter)]
    cpo_set = set(zip(cpo.Stkcd, cpo.quarter))
    grid["commercial_paper_overdue"] = [int((s, q) in cpo_set)
                                        for s, q in zip(grid.Stkcd, grid.quarter)]
    grid["interest_overdue"] = [1 if (s, q) in set(zip(dft.Stkcd, dft.quarter)) else 0
                                for s, q in zip(grid.Stkcd, grid.quarter)]
    grid["rating_downgrade"] = [1 if (s, q) in rat_dn else 0 for s, q in zip(grid.Stkcd, grid.quarter)]
    grid["outlook_negative"] = [1 if (s, q) in rat_ol else 0 for s, q in zip(grid.Stkcd, grid.quarter)]
    grid["regulatory_inquiry"] = [1 if (s, q) in inq_set else 0 for s, q in zip(grid.Stkcd, grid.quarter)]

    # Credit-spread jump: d = spread - same-industry same-quarter median;
    # flagged when d - mean(prior <= 8 d) > std(prior <= 8 d);
    # fallback d > 25 bp when history < 4 periods
    seg_of = dict(zip(firm_meta.Stkcd, firm_meta.Industry_Chain_Link.map(LINK2SEG)))
    yld = _read(DATA_AK / "bond_yield_quarterly.csv")
    yld["segment"] = yld.Stkcd.map(seg_of)
    med = yld.groupby(["segment", "quarter"]).spread_bp.transform("median")
    yld["d"] = yld.spread_bp - med
    yld["qi"] = yld.quarter.map(q_index)
    yld = yld.sort_values(["Stkcd", "qi"])
    spread_set = set()
    for stk, g in yld.groupby("Stkcd", sort=False):
        vals = []
        for r in g.itertuples():
            if len(vals) >= 4:
                arr = np.asarray(vals[-8:])
                mu, sd = arr.mean(), arr.std(ddof=0)
                hit = (r.d - mu) > sd if sd > 1e-9 else r.d > 25
            else:
                hit = r.d > 25
            if hit:
                spread_set.add((r.Stkcd, r.quarter))
            vals.append(r.d)
    grid["credit_spread_jump"] = [1 if (s, q) in spread_set else 0
                                  for s, q in zip(grid.Stkcd, grid.quarter)]

    grid["quarter_index"] = grid.quarter.map(q_index)
    ev = grid[grid[FLAG_COLS].sum(axis=1) > 0].copy()
    return ev.sort_values(["Stkcd", "quarter_index"]).reset_index(drop=True)


# ------------------------------------------------------------------ labels
def build_labels(panel: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    """Point-in-time labelling at the window-ending quarter: high risk first, then medium, otherwise low."""
    lab = panel[["Stkcd", "quarter"]].copy()
    lab["label"] = "low"
    lab["label_source"] = "none"
    ev = events.set_index(["Stkcd", "quarter"])
    for k, r in ev.iterrows():
        flags = [name for name in EVENT_HIGH if r.get(name, 0) == 1] + \
                [name for name in EVENT_MID if r.get(name, 0) == 1]
        if not flags:
            continue
        src = min(flags, key=SOURCE_PRIORITY.index)
        kmask = (lab.Stkcd == k[0]) & (lab.quarter == k[1])
        lab.loc[kmask, "label"] = "high" if src in EVENT_HIGH else "mid"
        lab.loc[kmask, "label_source"] = (EVENT_HIGH | EVENT_MID)[src]
    return lab


# ------------------------------------------------------------------ windows
def build_windows(panel: pd.DataFrame, labels: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Enumerate candidate windows over the full grid: length 8, step 1; windows with any missing panel quarter are excluded."""
    lab_map = labels.set_index(["Stkcd", "quarter"])[["label", "label_source"]].to_dict("index")
    stkcs = sorted(panel.Stkcd.unique())
    have = set(zip(panel.Stkcd, panel.quarter))

    rows = []
    n_cand = 0
    for stk in stkcs:
        for w in range(1, len(QUARTERS) - WINDOW_T + 2):
            n_cand += 1
            qs = QUARTERS[w - 1: w - 1 + WINDOW_T]
            end_q = qs[-1]
            if any((stk, q) not in have for q in qs):
                rows.append({"Stkcd": stk, "win_index": w,
                             "win_start_quarter": qs[0], "win_end_quarter": end_q,
                             "status": "excluded_late_listing"})
                continue
            info = lab_map[(stk, end_q)]
            split = ("train" if q_index(end_q) <= q_index(TRAIN_END_Q)
                     else "test" if q_index(end_q) >= q_index(TEST_START_Q)
                     else "skip")
            rows.append({"Stkcd": stk, "win_index": w,
                         "win_start_quarter": qs[0], "win_end_quarter": end_q,
                         "status": "valid", "split": split,
                         "risk_label": info["label"],
                         "label_source": info["label_source"]})
    W = pd.DataFrame(rows)
    firm_meta = _read(DATA_INT / "firm_meta.csv")
    id_of = dict(zip(firm_meta.Stkcd, firm_meta.firm_id))
    W["firm_id"] = W.Stkcd.map(id_of)
    meta = {"n_candidate": n_cand,
            "n_valid": int((W.status == "valid").sum()),
            "n_excluded": int((W.status != "valid").sum())}
    return W, meta


def build_tensor(panel: pd.DataFrame, W_valid: pd.DataFrame, *, strict_pit=False) -> tuple:
    """Window feature tensor (PIT fallback at the final step + forward fill)."""
    pmap = panel.set_index(["Stkcd", "quarter"])
    X, y, groups, qtrs = [], [], [], []
    for r in W_valid.itertuples():
        qs = QUARTERS[q_index(r.win_start_quarter): q_index(r.win_end_quarter) + 1]
        block = np.full((WINDOW_T, len(FEATURES)), np.nan)
        cutoff = pd.Timestamp(QEND[r.win_end_quarter])
        for t, q in enumerate(qs):
            use_q = q
            if strict_pit:
                # A historical quarterly report is usable iff it had actually
                # been published by this prediction window's end date.
                candidates=[prior for prior in QUARTERS[:q_index(q)+1]
                            if (r.Stkcd,prior) in pmap.index and
                            pd.Timestamp(pmap.loc[(r.Stkcd,prior),'ann_date'])<=cutoff]
                if not candidates:
                    raise ValueError(f'No PIT-eligible report for {r.Stkcd}, {q}, cutoff={cutoff}')
                use_q=candidates[-1]
            elif t == WINDOW_T - 1:
                ann = pmap.loc[(r.Stkcd, q), "ann_date"]
                if pd.Timestamp(ann) > pd.Timestamp(QEND[q]):
                    use_q = QUARTERS[q_index(q) - 1]
            block[t] = pmap.loc[(r.Stkcd, use_q), FEATURES].to_numpy(dtype=float)
        block = forward_fill(block)
        assert not np.isnan(block).any(), f"window features still contain NaN: {r.Stkcd} {r.win_end_quarter}"
        X.append(block)
        y.append(RISK_CODE[r.risk_label])
        groups.append(r.Stkcd)
        qtrs.append([q_index(q) for q in qs])
    return np.asarray(X), np.asarray(y, dtype=np.int64), np.asarray(groups), np.asarray(qtrs, dtype=np.int32)


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description='Rebuild labels with explicit source-evidence policy')
    ap.add_argument('--label-mode',choices=['verified','legacy'],default='verified',
                    help='verified requires local original official evidence; legacy replays unverified author snapshot')
    args = ap.parse_args()
    label_mode=args.label_mode
    if label_mode=='verified':
        # Fail BEFORE writing a new final label or modifying author snapshots.
        validate_official('st_status_verified.csv')
        validate_official('commercial_paper_verified.csv')
        issues=validate_coverage()
        if issues:
            raise ValueError(f'{len(issues)} official-source review items unresolved; examples: {issues[:3]}')
    out_dir = (DATA_INT if label_mode=='legacy'
               else PKG/'01_data'/'verified_candidate')
    out_dir.mkdir(parents=True,exist_ok=True)
    panel = build_panel(strict_pit=(label_mode=="verified"))
    events = build_events(label_mode=label_mode)
    labels = build_labels(panel, events)
    W, meta = build_windows(panel, labels)
    v = W[W.status == "valid"].copy()
    lab2c = {"low": "L", "mid": "M", "high": "H"}

    if label_mode=="legacy":
        # ---- Reconciliation 1: event flags vs the shipped baseline (events_firm_quarter.csv) ----
        base_ev = _read(DATA_INT / "events_firm_quarter.csv")
        fmap = _read(DATA_INT / "firm_meta.csv")[["firm_id", "Stkcd"]]
        base_ev = base_ev.merge(fmap, on="firm_id", how="left")
        chk = base_ev.merge(events, on=["Stkcd", "quarter"], how="outer",
                            suffixes=("", "_new"), indicator=True)
        both = chk[chk._merge.isin(["left_only", "both"])]
        for c in FLAG_COLS:
            a = both[c].fillna(0).astype(int)
            b = both[c + "_new"].fillna(0).astype(int)
            bad = int((a != b).sum())
            assert bad == 0, f"event-flag reconciliation failed: {c} mismatched on {bad} rows"
        extra = int((chk._merge == "right_only").sum())
        assert extra == 0, f"reconstructed events contain {extra} flagged quarters outside the baseline"

        # ---- Reconciliation 2: windows/split/labels vs the shipped baseline (window_labels_expected.csv) ----
        exp = pd.read_csv(BASE_PRED / "window_labels_expected.csv", dtype={"firm_id": str})
        v = W[W.status == "valid"].copy()
        mg = v.merge(exp, on=["firm_id", "win_index"], suffixes=("", "_exp"))
        assert len(mg) == len(exp) == meta["n_valid"], "valid-window count differs from the baseline"
        lab2c = {"low": "L", "mid": "M", "high": "H"}
        assert (mg.risk_label.map(lab2c) == mg.ground_truth_label).all(), "labels differ from the baseline"
        assert (mg.split == mg.split_exp).all(), "split differs from the baseline"
        assert (mg.label_source == mg.event_sources).all(), "label provenance differs from the baseline"
        inv = W[W.status != "valid"]
        assert len(inv) == 205 == meta["n_excluded"], f"excluded-window count {meta['n_excluded']} != 205"
        exp_set = set(zip(exp.firm_id, exp.win_index))
        assert not any((f, w) in exp_set for f, w in zip(inv.firm_id, inv.win_index)), \
            "excluded windows must not appear in the valid baseline"
        ws = pd.read_csv(BASE_PRED / "window_split.csv", dtype={"firm_id": str})
        mgs = v[["firm_id", "win_index", "split", "risk_label"]].merge(
            ws[ws.status == "valid"][["firm_id", "win_index", "split", "risk_label"]],
            on=["firm_id", "win_index"], suffixes=("", "_pred"))
        assert (mgs.split == mgs.split_pred).all(), "split differs from window_split.csv"
        lab2c = {"low": "L", "mid": "M", "high": "H"}
        assert (mgs.risk_label.map(lab2c) == mgs.risk_label_pred).all(), "labels differ from window_split.csv"

    firm_meta = _read(DATA_INT / "firm_meta.csv")
    seg_of = dict(zip(firm_meta.Stkcd, firm_meta.Industry_Chain_Link.map(LINK2SEG)))
    W["industry"] = W.Stkcd.map(seg_of)

    X, y, groups, qtrs = build_tensor(panel, v, strict_pit=(label_mode=="verified"))
    np.savez_compressed(out_dir / "window_tensor.npz", X=X, y=y, groups=groups,
                        quarters=qtrs, features=np.array(FEATURES, dtype=object))

    if label_mode=='verified':
        # Do not silently overwrite original labels or experiment predictions.
        meta_stk=_read(DATA_INT / 'firm_meta.csv')[['Stkcd','firm_id']]
        eve=events.merge(meta_stk,on='Stkcd',how='left')
        eve[['firm_id','quarter','quarter_index']+FLAG_COLS].to_csv(
            out_dir/'events_firm_quarter.csv',index=False,encoding='utf-8-sig')
        v[['firm_id','win_index','win_start_quarter','win_end_quarter','split','risk_label','label_source']].to_csv(
            out_dir/'window_labels_candidate.csv',index=False,encoding='utf-8-sig')
    W.to_csv(out_dir / "windows.csv", index=False, encoding="utf-8-sig")
    panel.to_csv(out_dir / "panel_quarterly.csv", index=False, encoding="utf-8-sig")
    events.to_csv(out_dir / "events.csv", index=False, encoding="utf-8-sig")
    labels.to_csv(out_dir / "label_source.csv", index=False, encoding="utf-8-sig")

    meta.update({
        "n_train": int((v.split == "train").sum()),
        "n_test": int((v.split == "test").sum()),
        "labels_all": v.risk_label.map(lab2c).value_counts().to_dict(),
        "labels_test": v[v.split == "test"].risk_label.map(lab2c).value_counts().to_dict(),
        "valid_by_segment": W[W.status == "valid"].groupby(["industry", "split"]).size().unstack(fill_value=0).to_dict(),
        "window_T": WINDOW_T, "window_S": WINDOW_S,
        "features": FEATURES, "aux_features": AUX_FEATURES,
        "train_end": TRAIN_END_Q, "test_start": TEST_START_Q,
        "reconciliation": ("legacy event flags, windows and predictions replayed against the historical snapshot"
                            if label_mode=='legacy' else "not compared with legacy labels; predictions must be regenerated"),
        "label_mode": label_mode,
        "strict_point_in_time_features": label_mode == 'verified',
        "source_evidence_status": ("UNVERIFIED_LEGACY_CANDIDATES" if label_mode=='legacy'
                                   else "OFFICIAL_DOCUMENTS_LOCALLY_HASHED; authenticity must also be checked"),
    })
    (out_dir / "build_manifest.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    zp = zscore_params(panel, v, FEATURES)
    write_report(out_dir / "preprocessing_report.md", meta, zp, panel, v, FEATURES)
    print("build complete:")
    for k, val in meta.items():
        if k != "valid_by_segment":
            print(f"  {k}: {val}")


if __name__ == "__main__":
    main()
