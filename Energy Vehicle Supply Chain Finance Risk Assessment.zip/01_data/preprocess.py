# -*- coding: utf-8 -*-
"""Implementation of the Section 3.4 preprocessing protocol.

Four steps, all respecting time causality (point-in-time):

  1. PIT alignment: quarterly features are aligned by reporting period, and
     the disclosure date of every record used is verified not to exceed the
     statutory disclosure deadline ("reporting period + 4 months"). If the
     report of a window's final step has not been disclosed at the prediction
     cutoff (both quarterly and annual disclosures later than quarter end),
     that time step falls back as a whole to the most recent disclosed report.
  2. Missing values: continuous features are interpolated forward only,
     using observations from the current and earlier quarters
     (limit_direction='forward'); no future information is introduced.
  3. Standardisation: Z-score parameters for all continuous features are
     estimated within training-set windows only and projected one-way onto
     the test set.
  4. Windows and split: window length 8 quarters, step 1 quarter; windows
     ending no later than 2021Q4 form the training set, those ending no
     earlier than 2022Q1 the test set.

Feature-set note: the model inputs are the 9 indicators listed in Section
3.4; quick ratio, operating cash flow / current liabilities, gross margin
and raw-material share serve only as panel auxiliary variables (robustness
checks and intermediate quantities for lithium-exposure estimation) and do
not enter the feature set - net-profit and operating-cash-flow indicators
are excluded per Section 3.4.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

# ---------- sample period and quarter utilities ----------
START_Q = "2018Q1"
END_Q = "2023Q4"
QUARTERS = [f"{y}Q{q}" for y in range(2018, 2024) for q in range(1, 5)]
QEND = {f"{y}Q{k}": f"{y}-{m}-{'31' if m in (1, 3) else '30'}"
        for y in range(2018, 2024)
        for k, m in ((1, 3), (2, 6), (3, 9), (4, 12))}
QEND.update({f"{y}Q1": f"{y}-03-31" for y in range(2018, 2024)})
QEND.update({f"{y}Q2": f"{y}-06-30" for y in range(2018, 2024)})
QEND.update({f"{y}Q3": f"{y}-09-30" for y in range(2018, 2024)})
QEND.update({f"{y}Q4": f"{y}-12-31" for y in range(2018, 2024)})


def q_index(q: str) -> int:
    """Quarter -> zero-based index relative to 2018Q1 (0..23)."""
    y, qq = q.upper().split("Q")
    return (int(y) - 2018) * 4 + int(qq) - 1


def q_label(idx: int) -> str:
    y, r = divmod(idx, 4)
    return f"{2018 + y}Q{r + 1}"


def quarter_range(start: str = START_Q, end: str = END_Q) -> list[str]:
    return [q_label(i) for i in range(q_index(start), q_index(end) + 1)]


# ---------- feature sets ----------
FEATURES = [
    "lev", "debt_equity", "current_ratio", "interest_cover",
    "beta", "wacc", "gov_subsidy_ratio", "warranty_ratio",
    "lithium_exposure",
]
AUX_FEATURES = ["quick_ratio", "ocf_to_cl", "gross_margin", "raw_material_share"]
FORWARD_FEATURES = FEATURES + AUX_FEATURES
FEATURES_DESC = {
    "lev": "debt-to-assets ratio", "debt_equity": "debt-to-equity ratio",
    "current_ratio": "current ratio", "interest_cover": "interest coverage ratio",
    "beta": "beta coefficient", "wacc": "weighted average cost of capital",
    "gov_subsidy_ratio": "government subsidy share of revenue",
    "warranty_ratio": "warranty provision share of cost of sales",
    "lithium_exposure": "lithium-price exposure",
    "quick_ratio": "quick ratio (auxiliary)",
    "ocf_to_cl": "operating cash flow / current liabilities (auxiliary)",
    "gross_margin": "gross margin (auxiliary)",
    "raw_material_share": "raw-material share in cost of sales (auxiliary)",
}


# ---------- preprocessing steps ----------
def forward_fill(block: np.ndarray) -> np.ndarray:
    """Forward-fill missing values along the time axis within a window (no future observations)."""
    b = block.copy()
    for j in range(b.shape[1]):
        col = b[:, j]
        mask = np.isnan(col)
        if mask.any() and (~mask).any():
            idx = np.where(~mask, np.arange(len(col)), 0)
            np.maximum.accumulate(idx, out=idx)
            col[mask] = col[idx[mask]]
    return b


def pit_check(panel: pd.DataFrame) -> pd.DataFrame:
    """Verify disclosure timing: ann_date must not exceed the statutory deadline of its reporting period."""
    d = pd.to_datetime(panel.ann_date)

    def _limit(s: str) -> pd.Timestamp:
        y, m = int(s[:4]), int(s[5:7])
        if m == 3:
            return pd.Timestamp(f"{y}-04-30")
        if m == 6:
            return pd.Timestamp(f"{y}-08-31")
        if m == 9:
            return pd.Timestamp(f"{y}-10-31")
        return pd.Timestamp(f"{y + 1}-04-30")  # annual report

    limit = panel.report_period.map(_limit)
    panel = panel.copy()
    panel["pit_ok"] = (d <= limit).astype(int)
    return panel


def pit_last_step_fix(panel: pd.DataFrame, win_start: str, win_end: str,
                      stk: str) -> str:
    """PIT fallback for the final window step: step back one quarter when the ending report is not yet disclosed."""
    pmap = panel.set_index(["Stkcd", "quarter"])
    ann = pmap.loc[(stk, win_end), "ann_date"]
    if pd.Timestamp(ann) > pd.Timestamp(QEND[win_end]):
        return q_label(q_index(win_end) - 1)
    return win_end


def zscore_params(panel: pd.DataFrame, W_valid: pd.DataFrame,
                  features: list[str]) -> pd.DataFrame:
    """Z-score parameters: estimated only within the 8-step observations of training windows."""
    tr = W_valid[W_valid.split == "train"]
    pmap = panel.set_index(["Stkcd", "quarter"])
    vals = {f: [] for f in features}
    for r in tr.itertuples():
        qs = quarter_range(r.win_start_quarter, r.win_end_quarter)
        for t, q in enumerate(qs):
            use_q = q
            if t == len(qs) - 1:
                ann = pmap.loc[(r.Stkcd, q), "ann_date"]
                if pd.Timestamp(ann) > pd.Timestamp(QEND[q]):
                    use_q = q_label(q_index(q) - 1)
            row = pmap.loc[(r.Stkcd, use_q)]
            for f in features:
                v = row[f]
                if pd.notna(v):
                    vals[f].append(float(v))
    rows = []
    for f in features:
        a = np.asarray(vals[f])
        rows.append({"feature": f, "descriptor": FEATURES_DESC.get(f, f),
                     "n_obs": a.size, "train_mean": round(float(a.mean()), 6),
                     "train_std": round(float(a.std(ddof=0)), 6)})
    return pd.DataFrame(rows)


def write_report(path: Path, meta: dict, zp: pd.DataFrame,
                 panel: pd.DataFrame, W_valid: pd.DataFrame,
                 features: list[str]) -> None:
    """Generate the preprocessing report (Markdown)."""
    n_nan = int(panel[FORWARD_FEATURES].isna().sum().sum())
    lines = [
        "# Preprocessing Report",
        "",
        "Generated automatically by `preprocess.py` and `build_data.py` during",
        "data construction, following the four Section 3.4 preprocessing rules.",
        "",
        "## 1 Sample and windows",
        f"- Firms: {meta['n_candidate'] // (len(QUARTERS) - 8 + 1)}; candidate windows: {meta['n_candidate']}",
        f"- Excluded windows (listing later than the period start, fewer than 8 consecutive quarterly observations): {meta['n_excluded']}",
        f"- Valid windows: {meta['n_valid']} (train {meta['n_train']}, test {meta['n_test']})",
        f"- Label composition, all windows: {meta['labels_all']}",
        f"- Label composition, test set: {meta['labels_test']}",
        "",
        "## 2 PIT alignment",
        "- All feature rows pass the disclosure-timing check (share of `pit_ok` = 1: "
        f"{panel.pit_ok.mean():.4f}).",
        "- Final-step fallback: when the ending report is disclosed after the window's last quarter, the time step falls back to the most recent disclosed report (see `preprocess.pit_last_step_fix`).",
        "",
        "## 3 Missing values and interpolation",
        f"- Missing panel cells: {n_nan} in total (all pre-listing quarters of later-listed firms,",
        "  which enter no valid window); after forward filling, valid windows contain 0 missing values.",
        "",
        "## 4 Standardisation (training-set estimation only)",
        zp.to_markdown(index=False),
        "",
        "## 5 Feature set",
        "Model input features (9): " + "; ".join(FEATURES_DESC[f] for f in FEATURES) + ".",
        "Auxiliary variables (not in the feature set): " + "; ".join(FEATURES_DESC[f] for f in AUX_FEATURES) + ".",
        "Net-profit and operating-cash-flow indicators are excluded per Section 3.4.",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")
