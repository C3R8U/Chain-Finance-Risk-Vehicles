# -*- coding: utf-8 -*-
"""Read-only export from the CNEquity data lake -> 01_data/raw/cnequity/*.csv

Prerequisites
-------------
    pip install "cnequity==0.23.0"
    cne init                     # initialise the local data lake (Parquet + DuckDB, no registration)
    cne run daily                # update to the latest disclosure date

Run
---
    python extract_cnequity.py

The script only calls the read-only cnequity.query.load interface and never
writes to the data lake. Every exported row retains the statutory
first-disclosure date field (ann_date) for downstream PIT alignment; the
field list and filter criteria are documented in
01_data/cnequity_dataset_spec.csv.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from cnequity.query import load

HERE = Path(__file__).resolve().parent
RAW = HERE / "raw" / "cnequity"
RAW.mkdir(parents=True, exist_ok=True)

PERIOD = ("2018-01-01", "2023-12-31")
LOOKBACK = "2016-09-01"          # market-history lookback start for beta estimation
ERP = 0.065                      # equity risk premium
TAX = 0.15                       # effective income-tax rate (high-tech enterprise preferential rate)
MARKET_INDEX = "000300.SH"


def symbol_of(stk: str) -> str:
    """6-digit code -> CNEquity symbol: 6-prefixed codes trade in Shanghai, others in Shenzhen."""
    return f"{stk}.SH" if stk.startswith("6") else f"{stk}.SZ"


def sample_symbols() -> list[str]:
    meta = pd.read_csv(HERE / "interim" / "firm_meta.csv", dtype={"Stkcd": str})
    return [symbol_of(s) for s in meta.Stkcd]


def qlabel(ts) -> str:
    return f"{ts.year}Q{(ts.month - 1) // 3 + 1}"


def qend(q: str) -> str:
    y, k = q.split("Q")
    return {"1": f"{y}-03-31", "2": f"{y}-06-30", "3": f"{y}-09-30", "4": f"{y}-12-31"}[k]


# --------------------------------------------------------------- statements and notes
def export_financial_items(symbols: list[str]) -> pd.DataFrame:
    df = load("financial_statement_items", symbols=symbols,
              start=PERIOD[0], end=PERIOD[1], statement_type="consolidated quarterly")
    cols = ["Stkcd", "report_period", "ann_date", "statement_type",
            "total_assets", "total_liab", "total_equity",
            "total_current_assets", "total_current_liab", "inventory",
            "revenue", "cost_of_sales", "ebit", "interest_expense",
            "net_profit", "net_cash_operating"]
    out = df[cols].copy()
    out["Stkcd"] = out.Stkcd.str.slice(0, 6)
    out.to_csv(RAW / "financial_statement_items.csv", index=False, encoding="utf-8-sig")
    return out


def export_notes(symbols: list[str]) -> None:
    for dataset, col, fname in (
            ("notes_gov_subsidy", "gov_subsidy", "notes_gov_subsidy.csv"),
            ("notes_warranty_provision", "warranty_provision", "notes_warranty_provision.csv"),
            ("notes_cost_structure", "raw_material_cost", "notes_cost_structure.csv")):
        df = load(dataset, symbols=symbols, start=PERIOD[0], end=PERIOD[1])
        keep = ["Stkcd", "report_period", "ann_date", col, "note_item"]
        out = df[keep].copy()
        out["Stkcd"] = out.Stkcd.str.slice(0, 6)
        out.to_csv(RAW / fname, index=False, encoding="utf-8-sig")


# --------------------------------------------------------------- market data and derived series
def _weekly_returns(close: pd.Series) -> pd.Series:
    return close.pct_change().resample("W-FRI").last()


def export_beta(symbols: list[str]) -> pd.DataFrame:
    """Beta = rolling 60-week OLS slope of firm weekly returns on CSI 300 weekly returns, sampled at quarter ends."""
    idx = load("index_daily", symbols=[MARKET_INDEX], start=LOOKBACK, end=PERIOD[1])
    m = _weekly_returns(idx.set_index("date")["close"])
    rows = []
    for sym in symbols:
        bars = load("daily_bars", symbols=[sym], start=LOOKBACK, end=PERIOD[1])
        if bars.empty:
            continue
        s = _weekly_returns(bars.set_index("date")["close"])
        pair = pd.concat({"stock": s, "market": m}, axis=1).dropna()
        for per, grp in pair.groupby(pair.index.to_period("Q")):
            if len(grp) < 60:
                continue
            w = grp.tail(60)
            vx = float(np.var(w.market, ddof=1))
            if vx <= 0:
                continue
            rows.append({"Stkcd": sym[:6], "quarter": qlabel(per.end_time),
                         "beta": round(float(np.cov(w.stock, w.market, ddof=1)[0, 1] / vx), 4),
                         "est_window": "rolling 60 weeks", "source_index": "CSI000300",
                         "calc_date": str(grp.index[-1].date())})
    out = pd.DataFrame(rows).sort_values(["Stkcd", "quarter"])
    out.to_csv(RAW / "beta_quarterly.csv", index=False, encoding="utf-8-sig")
    return out


def export_wacc(fin: pd.DataFrame, beta: pd.DataFrame) -> pd.DataFrame:
    """WACC = E/(D+E)*ke + D/(D+E)*kd*(1-T), quarterly frequency.

    ke follows CAPM (Rf = quarterly mean of the 10Y CGB yield); kd is
    approximated by interest expense over interest-bearing debt
    (total liabilities x 0.72). D and E are book values of the same
    reporting period.
    """
    bond = load("bond_cn_10y", start="2017-12-01", end=PERIOD[1])
    rf = {qlabel(p): float(v) for p, v in
          bond.set_index("date")["yield"].resample("QE").mean().items()}
    fin = fin.copy()
    fin["quarter"] = pd.to_datetime(fin.report_period).map(qlabel)
    bmap = {(r.Stkcd, r.quarter): r.beta for r in beta.itertuples()}
    rows = []
    for r in fin.itertuples():
        b = bmap.get((r.Stkcd, r.quarter))
        if b is None:
            continue
        debt = float(r.total_liab) * 0.72
        equity = float(r.total_equity)
        if debt + equity <= 0:
            continue
        ke = rf.get(r.quarter, 0.028) + b * ERP
        kd = float(r.interest_expense) / max(debt, 1.0)
        wacc = equity / (debt + equity) * ke + debt / (debt + equity) * kd * (1 - TAX)
        rows.append({"Stkcd": r.Stkcd, "quarter": r.quarter, "wacc": round(wacc, 4),
                     "risk_free": "10Y CGB yield (quarterly mean)",
                     "erp_source": "CNEquity index_daily", "calc_date": qend(r.quarter)})
    out = pd.DataFrame(rows).sort_values(["Stkcd", "quarter"])
    out.to_csv(RAW / "wacc_quarterly.csv", index=False, encoding="utf-8-sig")
    return out


def export_lithium() -> None:
    """Battery-grade lithium carbonate spot price -> quarterly average (CNY/t)."""
    px = load("commodity_spot", symbols=["LI-CARB-99.5"], start=PERIOD[0], end=PERIOD[1])
    q = px.set_index("date")["price"].resample("QE").mean().dropna()
    out = pd.DataFrame({"quarter": [qlabel(p) for p in q.index],
                        "lithium_price": q.round(0).astype(int).values,
                        "unit": "CNY/t",
                        "spec": "battery-grade lithium carbonate (99.5%), quarterly average",
                        "source": "CNEquity commodity_spot"})
    out.to_csv(RAW / "lithium_price.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    symbols = sample_symbols()
    fin = export_financial_items(symbols)
    export_notes(symbols)
    beta = export_beta(symbols)
    export_wacc(fin, beta)
    export_lithium()
    print(f"CNEquity export finished: {len(symbols)} sample firms -> {RAW}")


if __name__ == "__main__":
    main()
