# Preprocessing Report

Generated automatically by `preprocess.py` and `build_data.py` during
data construction, following the four Section 3.4 preprocessing rules.

## 1 Sample and windows
- Firms: 138; candidate windows: 2346
- Excluded windows (listing later than the period start, fewer than 8 consecutive quarterly observations): 205
- Valid windows: 2141 (train 1039, test 1102)
- Label composition, all windows: {'L': 1288, 'M': 647, 'H': 206}
- Label composition, test set: {'L': 664, 'M': 342, 'H': 96}

## 2 PIT alignment
- All feature rows pass the disclosure-timing check (share of `pit_ok` = 1: 1.0000).
- Final-step fallback: when the ending report is disclosed after the window's last quarter, the time step falls back to the most recent disclosed report (see `preprocess.pit_last_step_fix`).

## 3 Missing values and interpolation
- Missing panel cells: 3 in total (all pre-listing quarters of later-listed firms,
  which enter no valid window); after forward filling, valid windows contain 0 missing values.

## 4 Standardisation (training-set estimation only)
| feature           | descriptor                                |   n_obs |   train_mean |   train_std |
|:------------------|:------------------------------------------|--------:|-------------:|------------:|
| lev               | debt-to-assets ratio                      |    8312 |     0.303545 |    0.098918 |
| debt_equity       | debt-to-equity ratio                      |    8312 |     0.471101 |    0.255508 |
| current_ratio     | current ratio                             |    8312 |     0.810472 |    0.211697 |
| interest_cover    | interest coverage ratio                   |    8312 |     2.98773  |    3.18121  |
| beta              | beta coefficient                          |    8312 |     1.05945  |    0.212646 |
| wacc              | weighted average cost of capital          |    8312 |     0.071227 |    0.01683  |
| gov_subsidy_ratio | government subsidy share of revenue       |    8312 |     0.030799 |    0.016156 |
| warranty_ratio    | warranty provision share of cost of sales |    8312 |     0.012047 |    0.008298 |
| lithium_exposure  | lithium-price exposure                    |    8312 |     0.001997 |    0.00273  |

## 5 Feature set
Model input features (9): debt-to-assets ratio; debt-to-equity ratio; current ratio; interest coverage ratio; beta coefficient; weighted average cost of capital; government subsidy share of revenue; warranty provision share of cost of sales; lithium-price exposure.
Auxiliary variables (not in the feature set): quick ratio (auxiliary); operating cash flow / current liabilities (auxiliary); gross margin (auxiliary); raw-material share in cost of sales (auxiliary).
Net-profit and operating-cash-flow indicators are excluded per Section 3.4.
