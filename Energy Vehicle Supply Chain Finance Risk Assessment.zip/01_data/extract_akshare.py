# -*- coding: utf-8 -*-
"""Extract auxiliary securities events via AKShare.

Commercial-paper official overdue lists are NOT an AKShare interface and are
never inferred from a title keyword search. They must be ingested as official
monthly list attachments and checked by 01_data/source_audit.py.

Usage:
    pip install akshare
    python extract_akshare.py            # full extraction (local cache, idempotent)

Extraction scope and field lists are documented in
01_data/akshare_interface_spec.csv. The sample pool (138 firm codes) comes
from 01_data/interim/firm_meta.csv. Interface payloads follow the original
disclosure sources; this script only normalises fields and time intervals
without altering disclosed facts. The shipped raw/akshare/*.csv files are
extraction snapshots (retrieval date in 05_docs/session_info.txt).

Note: disclosure-title keyword filters and upstream API column names retain
their original Chinese wording, since the underlying public disclosures are
published in Chinese.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

try:
    import akshare as ak
except ImportError:
    ak = None  # offline official-list verification does not require AKShare
import pandas as pd

HERE = Path(__file__).resolve().parent
RAW = HERE / "raw" / "akshare"
RAW.mkdir(parents=True, exist_ok=True)
META = pd.read_csv(HERE / "interim" / "firm_meta.csv", dtype={"Stkcd": str})
STKS = META.Stkcd.tolist()
PERIOD = ("2018-01-01", "2023-12-31")
SLEEP = 0.35  # interface rate limit


def _quarter_of(s: str) -> str:
    d = pd.Timestamp(s)
    return f"{d.year}Q{(d.month - 1) // 3 + 1}"


def _qend(q: str) -> str:
    y, k = q.split("Q")
    return {"1": f"{y}-03-31", "2": f"{y}-06-30",
            "3": f"{y}-09-30", "4": f"{y}-12-31"}[k]


def extract_st_status():
    """Historical ST status MUST be reconstructed from original exchange notices.

    The currently available AKShare ST-stock list is a current cross-section;
    it cannot independently supply historical implementation/revocation dates.
    """
    raise RuntimeError(
        'Historical ST effective intervals cannot be reconstructed from a current '
        'ST-stock list. Import original official exchange notices into '
        '01_data/raw/official/st_status_verified.csv and audit every interval.')


def extract_audit_opinion():
    """Annual-report audit opinions (cninfo announcements, filtered by title keywords)."""
    rows = []
    for stk in STKS:
        df = ak.stock_zh_a_disclosure_report_cninfo(
            symbol=stk, market="年报", start_date=PERIOD[0], end_date="2024-04-30")
        for r in df.itertuples():
            title = str(getattr(r, "公告标题", ""))
            if not any(k in title for k in ("审计意见", "审计报告")):
                continue
            if "标准无保留" in title and "带强调事项" not in title:
                continue
            rows.append({"Stkcd": stk,
                         "report_period": str(pd.Timestamp(r.公告日期).year - 1) + "-12-31",
                         "fiscal_year": pd.Timestamp(r.公告日期).year - 1,
                         "opinion_type": title,
                         "ann_date": str(pd.Timestamp(r.公告日期).date()),
                         "clearance_date": "",
                         "audit_agency": "",
                         "source": "AKShare stock_zh_a_disclosure_report_cninfo"})
        time.sleep(SLEEP)
    pd.DataFrame(rows).sort_values(["Stkcd", "ann_date"]).to_csv(
        RAW / "audit_opinion.csv", index=False, encoding="utf-8-sig")


def extract_commercial_paper_overdue():
    """No public AKShare endpoint established for official historical lists.

    The previously used announcement-title matching logic is intentionally
    disabled: it does not provide issuer-specific official list evidence.
    """
    raise RuntimeError(
        'Commercial-paper overdue data must be imported from Shanghai '
        'Commercial Paper Exchange official monthly list attachments. '
        'Populate 01_data/raw/official/commercial_paper_verified.csv '
        'with original announcement URLs, publication dates and hashes, '
        'then run: python 01_data/source_audit.py --require-complete')


def extract_bond_default():
    """Bond interest defaults (public default records)."""
    df = ak.bond_zh_default()
    name2stk = dict(zip(META.Company_Name, META.Stkcd))
    sel = df[df["发行人"].isin(name2stk)]
    rows = []
    for r in sel.itertuples():
        d = pd.Timestamp(str(r.违约日期))
        rows.append({"Stkcd": name2stk.get(str(r.发行人), ""),
                     "bond_code": getattr(r, "债券代码", ""),
                     "default_date": str(d.date()),
                     "quarter": _quarter_of(str(d.date())),
                     "default_type": "interest payment default",
                     "status": "insufficient redemption",
                     "source": "AKShare bond_zh_default"})
    pd.DataFrame(rows).sort_values(["default_date"]).to_csv(
        RAW / "bond_interest_default.csv", index=False, encoding="utf-8-sig")


def extract_rating_change():
    """Issuer rating downgrades and negative outlooks (public rating announcements via cninfo)."""
    rows = []
    for stk in STKS:
        df = ak.stock_zh_a_disclosure_report_cninfo(
            symbol=stk, market="其他", start_date=PERIOD[0], end_date=PERIOD[1])
        for r in df.itertuples():
            title = str(getattr(r, "公告标题", ""))
            if "评级" not in title:
                continue
            if "下调" in title or ("展望" in title and "负面" in title):
                direction = "rating downgrade" if "下调" in title else "outlook revised to negative"
                rows.append({"Stkcd": stk,
                             "ann_date": str(pd.Timestamp(r.公告日期).date()),
                             "direction": direction,
                             "from_rating": "", "to_rating": "",
                             "outlook_change": "stable/positive -> negative"
                             if direction == "outlook revised to negative" else "",
                             "agency": "", "effect_until": "",
                             "source": "AKShare bond_credit_rating (public rating announcements)"})
        time.sleep(SLEEP)
    pd.DataFrame(rows).sort_values(["Stkcd", "ann_date"]).to_csv(
        RAW / "bond_rating_change.csv", index=False, encoding="utf-8-sig")


def extract_inquiry():
    """Regulatory inquiry / attention letters (cninfo, filtered by title keywords)."""
    rows = []
    for stk in STKS:
        df = ak.stock_zh_a_disclosure_report_cninfo(
            symbol=stk, market="其他", start_date=PERIOD[0], end_date=PERIOD[1])
        for r in df.itertuples():
            title = str(getattr(r, "公告标题", ""))
            if ("问询函" in title or "关注函" in title) and "回复" not in title:
                rows.append({"Stkcd": stk,
                             "letter_date": str(pd.Timestamp(r.公告日期).date()),
                             "letter_type": "inquiry letter" if "问询函" in title else "attention letter",
                             "letter_no": title,
                             "reply_date": "",
                             "exchange": "SSE" if stk.startswith("6") else "SZSE",
                             "source": "AKShare stock_zh_a_disclosure_report_cninfo"})
        time.sleep(SLEEP)
    pd.DataFrame(rows).sort_values(["Stkcd", "letter_date"]).to_csv(
        RAW / "regulatory_inquiry.csv", index=False, encoding="utf-8-sig")


def extract_bond_yield():
    """Guard against misusing exchange-traded bond prices as YTM.

    Source bond_zh_hs_cov_daily provides closing prices; those prices are NOT
    bond yields. A genuine maturity-matched yield spread needs bond cash-flow
    terms, maturity, a compatible benchmark and actual observation dates.
    Existing historical raw data are preserved separately as a snapshot.
    """
    raise RuntimeError(
        'No documented AKShare routine in this package yields the issuer-level '
        'maturity-matched quarterly bond YTM required by the manuscript. '
        'Do not convert a bond closing price into a percentage yield. '
        'Supply independently verified quarterly yield/spread data.')


def _cov_bonds_of(stk: str) -> list[str]:
    """Outstanding-bond codes of a sample firm (issuer matching; cached in raw/akshare/bond_map.csv)."""
    cache = RAW / "bond_map.csv"
    if cache.exists():
        m = pd.read_csv(cache, dtype=str)
        return m[m.Stkcd == stk].bond_code.tolist()
    df = ak.bond_cov()
    rows = []
    meta_names = {n: s for n, s in
                  zip(META.Company_Name, META.Stkcd)}
    for r in df.itertuples():
        name = str(getattr(r, "发行人", "")) if hasattr(r, "发行人") else ""
        if name in meta_names:
            rows.append({"Stkcd": meta_names[name],
                         "bond_code": str(getattr(r, "债券代码", ""))})
    pd.DataFrame(rows).to_csv(cache, index=False, encoding="utf-8-sig")
    m = pd.read_csv(cache, dtype=str)
    return m[m.Stkcd == stk].bond_code.tolist()


if __name__ == "__main__":
    if ak is None:
        raise SystemExit('AKShare not installed; official list audit runs independently')
    print('Skipping historical ST extraction: original exchange notices required.')
    extract_audit_opinion()
    print("Skipping commercial paper: no verified AKShare direct list interface; see official source audit.")
    extract_bond_default()
    extract_rating_change()
    extract_inquiry()
    print('Skipping issuer yield/spread extraction: bond prices are not yields; use verified data.')
    print('AKShare auxiliary disclosure extraction finished ->', RAW)
