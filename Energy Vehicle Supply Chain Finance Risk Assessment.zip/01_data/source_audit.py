# -*- coding: utf-8 -*-
"""Independent, local evidence gate for ST and official monthly commercial paper lists.

A valid schema and a matching downloaded file hash do not independently prove that
an upstream disclosure is authentic; retain the issuer/official URL and check it.
The original unverified candidate event snapshots are NEVER treated as verified.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OFFICIAL = ROOT / '01_data' / 'raw' / 'official'
EVIDENCE = OFFICIAL / 'evidence'
REQUIRED = {
    'commercial_paper_verified.csv': ['Stkcd','acceptor_name','unified_social_credit_code','list_month','publication_date','list_type','official_source_url','evidence_file','evidence_sha256'],
    'st_status_verified.csv': ['Stkcd','st_type','in_date','out_date','exchange','publication_date','official_source_url','evidence_file','evidence_sha256'],
}


def _valid_source_url(s):
    if not isinstance(s, str) or not s.startswith('https://'):
        return False
    host = (urlparse(s).hostname or '').lower()
    return host.endswith('.shcpe.com.cn') or host == 'shcpe.com.cn' or host.endswith('.sse.com.cn') or host == 'sse.com.cn' or host.endswith('.szse.cn') or host == 'szse.cn' or host.endswith('.bse.cn') or host == 'bse.cn' or host.endswith('.cninfo.com.cn') or host == 'cninfo.com.cn'


def validate(filename, require_nonempty=True):
    p = OFFICIAL / filename
    if not p.is_file():
        raise ValueError(f'Missing official-event file: {p}')
    df = pd.read_csv(p, dtype=str, keep_default_na=False, encoding='utf-8-sig')
    missing = [x for x in REQUIRED[filename] if x not in df.columns]
    if missing: raise ValueError(f'{filename} lacks columns: {missing}')
    if require_nonempty and len(df) == 0:
        raise ValueError(f'{filename} is empty: no official evidence has been supplied')
    known = set(pd.read_csv(ROOT/'01_data/interim/firm_meta.csv', dtype={'Stkcd':str}).Stkcd)
    for ix, r in df.iterrows():
        row=f'{filename} row {ix+2}'
        if not all(str(r[k]).strip() for k in REQUIRED[filename] if k != 'out_date'):
            raise ValueError(row+': missing required source-identification field')
        if r['Stkcd'] not in known: raise ValueError(row+': stock code not in study sample')
        if not _valid_source_url(r['official_source_url']):
            raise ValueError(row+': URL must point to official exchange/disclosure domain')
        file_rel=Path(r['evidence_file'])
        if file_rel.is_absolute() or '..' in file_rel.parts:
            raise ValueError(row+': invalid evidence path')
        evidence=(EVIDENCE/file_rel).resolve()
        if not evidence.is_file() or not evidence.is_relative_to(EVIDENCE.resolve()):
            raise ValueError(row+': evidence file unavailable; do not use a fabricated hash')
        digest=hashlib.sha256(evidence.read_bytes()).hexdigest()
        if digest.lower()!=r['evidence_sha256'].lower():
            raise ValueError(row+': evidence SHA256 mismatch')
        pub=pd.to_datetime(r['publication_date'],errors='coerce')
        if pd.isna(pub): raise ValueError(row+': invalid actual publication date')
        if filename.startswith('commercial'):
            mon=r['list_month']
            try: month=pd.Period(mon,freq='M')
            except Exception as e: raise ValueError(row+': invalid month YYYY-MM') from e
            if month < pd.Period('2021-08',freq='M') or pub < month.start_time:
                raise ValueError(row+': official publication predates the month covered')
            t=r['list_type']
            if month < pd.Period('2023-01',freq='M') and t!='pre2023_persistent_overdue':
                raise ValueError(row+': expected pre-2023 list type')
            if month >= pd.Period('2023-01',freq='M') and t not in ('acceptor_overdue','persistent_overdue'):
                raise ValueError(row+': post-2022 type must be acceptor_overdue or persistent_overdue')
        else:
            d0=pd.to_datetime(r['in_date'],errors='coerce')
            d1=pd.to_datetime(r['out_date'],errors='coerce') if r['out_date'] else pd.NaT
            if pd.isna(d0) or (pd.notna(d1) and d1<=d0):
                raise ValueError(row+': invalid ST effective interval')
            # The effective date must not precede public disclosure. Equal-day publication is valid.
            if pub > d0: raise ValueError(row+': implementation earlier than disclosure; verify date semantics')
            expected=('Shanghai Stock Exchange' if r['Stkcd'].startswith('6') else 'Shenzhen Stock Exchange' if r['Stkcd'].startswith(('0','3')) else 'Beijing Stock Exchange')
            if r['exchange']!=expected: raise ValueError(row+': ST exchange inconsistent with stock code')
    return df



def validate_coverage():
    """Every historical candidate must have an evidence-backed disposition.

    Having one or several verified announcements does NOT demonstrate that all
    37 commercial-paper and all 53 ST candidates have been adjudicated.
    Confirm/reject each original candidate independently. No inferred match,
    empty disposition or unsigned rejection is accepted as complete coverage.
    """
    name_map={
        'commercial_paper_source_review.csv': ('commercial_paper_verified.csv',
                                              'Stkcd','overdue_date','list_month'),
        'st_source_review.csv': ('st_status_verified.csv','Stkcd','in_date','in_date'),
    }
    issues=[]
    for review_file,(official_name,id_col,date_col,target_col) in name_map.items():
        path=ROOT/'01_data'/review_file
        review=pd.read_csv(path,dtype=str,keep_default_na=False,encoding='utf-8-sig')
        if 'verification' not in review or 'evidence_file' not in review or 'evidence_sha256' not in review:
            issues.append(f'{review_file}: missing status or evidence columns')
            continue
        verified=validate(official_name, require_nonempty=False)
        for _,r in review.iterrows():
            key=r.get('review_id','?')
            decision=str(r['verification']).strip()
            if decision not in ('CONFIRMED','REJECTED'):
                issues.append(f'{review_file} {key}: no final evidence-backed disposition')
                continue
            rel=Path(r['evidence_file'])
            if not str(r['evidence_file']).strip() or rel.is_absolute() or '..' in rel.parts:
                issues.append(f'{review_file} {key}: invalid evidence filename')
                continue
            evidence=EVIDENCE/rel
            if not evidence.is_file() or hashlib.sha256(evidence.read_bytes()).hexdigest()!=r['evidence_sha256'].lower():
                issues.append(f'{review_file} {key}: missing or mismatched evidence file')
                continue
            if not _valid_source_url(r.get('official_source_url','')):
                issues.append(f'{review_file} {key}: official source URL absent')
                continue
            if decision=='CONFIRMED':
                val_date=(pd.Timestamp(r[date_col]).strftime('%Y-%m') if target_col=='list_month'
                          else r[date_col])
                match=verified[(verified[id_col]==r[id_col]) & (verified[target_col]==val_date)]
                if match.empty:
                    issues.append(f'{review_file} {key}: marked confirmed, but no corresponding verified record')
    return issues


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--require-complete',action='store_true')
    args=a.parse_args()
    result={}
    for fn in REQUIRED:
        try:
            d=validate(fn,require_nonempty=True)
            result[fn]={'status':'SCHEMA_AND_LOCAL_EVIDENCE_OK','rows':len(d)}
        except (ValueError, OSError) as exc:
            result[fn]={'status':'PENDING','rows':0,'reason':str(exc)}
    if args.require_complete:
        try:
            issues=validate_coverage()
        except (ValueError,OSError,KeyError) as e:
            issues=[str(e)]
        result['candidate_coverage']={'status':'COMPLETE' if not issues else 'PENDING',
                                      'unresolved_count':len(issues),
                                      'sample_issues':issues[:8]}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 2 if args.require_complete and any(x['status']=='PENDING' for x in result.values()) else 0

if __name__=='__main__':
    raise SystemExit(main())
