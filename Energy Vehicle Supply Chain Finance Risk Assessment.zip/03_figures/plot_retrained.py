# -*- coding: utf-8 -*-
"""Generate new figure family from verified FULL re-training outputs.

New files are isolated from the historical snapshot. This script refuses
partial runs, so short diagnostic tests can never silently replace the paper's
figures. Requires both training stages with five complete seeds each.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]


def render(mode):
    p=ROOT/'04_outputs/retrained'/mode
    tab=p/'tables'
    required=[tab/'table4.csv',tab/'table5.csv',tab/'table6.csv',
              tab/'median_seed.txt']
    if any(not x.is_file() for x in required):
        raise RuntimeError('Both stages must be trained on all 5 seeds; compile_retrained.py first')
    fig=p/'figures';fig.mkdir(parents=True,exist_ok=True)
    models=pd.read_csv(tab/'table4.csv')
    ablations=pd.read_csv(tab/'table5.csv')
    preds=pd.read_csv(p/'main'/'predictions.csv',dtype={'Stkcd':str})
    median=int((tab/'median_seed.txt').read_text().strip())
    data=preds.query('model=="fca_bilstm" and seed==@median')
    from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
    cm=confusion_matrix(data.y_true,data.y_pred,labels=[1,2,3])
    prec,rec,f1,_=precision_recall_fscore_support(data.y_true,data.y_pred,labels=[1,2,3],zero_division=0)
    low=data[data.margin<0.35]
    f,ax=plt.subplots(1,3,figsize=(11,3.5))
    ax[0].imshow(cm,cmap='Blues');ax[0].set_title('(a) Confusion matrix')
    for i in range(3):
        for j in range(3):ax[0].text(j,i,str(cm[i,j]),ha='center',va='center')
    ax[0].set_xticks(range(3),['Low','Medium','High']);ax[0].set_yticks(range(3),['Low','Medium','High'])
    labels=['Precision','Recall','F1']
    for i,x in enumerate([prec,rec,f1]):
        ax[1].bar(np.arange(3)+i*.23-.23,x*100,.23,label=labels[i])
    ax[1].set_xticks(range(3),['Low','Medium','High']);ax[1].legend(fontsize=7)
    if len(low):
        a=(low.y_svm==low.y_true).mean()*100;b=(low.y_pred==low.y_true).mean()*100
        ax[2].bar(['SVM only','Cascade'],[a,b]);ax[2].set_ylim(0,100)
    ax[2].set_title('(c) Routed-subset accuracy')
    f.tight_layout();f.savefig(fig/'fig3_performance.png',dpi=250);plt.close(f)
    f,ax=plt.subplots(1,3,figsize=(12,3.5))
    ax[0].bar(range(len(models)),models.accuracy_mean*100,yerr=models.accuracy_sample_sd*100,capsize=3)
    ax[0].set_xticks(range(len(models)),models.model,rotation=35,ha='right',fontsize=6)
    ax[0].set_title('(a) Model comparison')
    ax[1].bar(range(len(ablations)),ablations.accuracy_mean*100,
              yerr=ablations.accuracy_sample_sd*100,capsize=3)
    ax[1].set_xticks(range(len(ablations)),ablations.model,rotation=35,ha='right',fontsize=6)
    ax[1].set_title('(b) Module ablation')
    theta=pd.read_csv(p/'main'/'theta_validation.csv')
    d=theta.query('config=="fca_bilstm" and seed==@median and split=="test"')
    ax[2].plot(d.theta,d.accuracy*100,'-o',ms=3)
    manifest=pd.read_csv(p/'main'/'run_manifest.csv')
    theta_star=manifest.query('model=="fca_bilstm" and seed==@median').theta.iloc[0]
    ax[2].axvline(theta_star,ls='--');ax[2].set_title('(c) Routing threshold')
    f.tight_layout();f.savefig(fig/'fig4_comparison.png',dpi=250);plt.close(f)
    W=pd.read_csv((ROOT/'01_data'/('verified_candidate' if mode=='verified' else 'interim')/'windows.csv'))
    W=W.query('status=="valid"')
    f,ax=plt.subplots(1,2,figsize=(8.5,3.2))
    g=W.groupby(['industry','split']).size().unstack(fill_value=0)
    g[['train','test']].plot(kind='bar',stacked=True,ax=ax[0]);ax[0].set_title('(a) Industry windows')
    cats=W.query('split=="test"').risk_label.value_counts()
    ax[1].bar(cats.index,cats.values);ax[1].set_title('(b) Test class distribution')
    f.tight_layout();f.savefig(fig/'figA1_sample.png',dpi=250);plt.close(f)
    paths=[('main','lstm'),('main','gru'),('main','tcn'),
           ('ablation','basic_bilstm_svm'),('ablation','no_temporal_attention'),('main','fca_bilstm')]
    f,ax=plt.subplots(figsize=(7.5,3.8))
    for stage,kind in paths:
        log=p/stage/'logs'/f'{kind}_seed{median}_epochs.csv'
        df=pd.read_csv(log)
        ax.plot(df.epoch,df.val_loss,label=kind)
    ax.set_xlabel('Epoch');ax.set_ylabel('Validation loss');ax.legend(fontsize=7,ncol=2)
    f.tight_layout();f.savefig(fig/'figA2_training.png',dpi=250);plt.close(f)
    print('New-run figures:',fig)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--data-mode',choices=['verified','legacy'],default='verified')
    a=ap.parse_args()
    render(a.data_mode)
