# -*- coding: utf-8 -*-
"""Render all manuscript figures (Python 3.10+, numpy/pandas/matplotlib only).

Figure inventory:
    fig3_performance    Fig. 3  Test-set classification performance
    fig4_comparison     Fig. 4  Model comparison and ablation
    figA1_sample        Fig. A1 Sample composition and test-set class distribution
    figA2_training      Fig. A2 Validation-loss convergence by model

All in-figure text is set in Arial. Inputs are read from 04_outputs/ and
01_data/interim/; outputs are written to 04_outputs/figures/ (PNG 300 dpi + PDF).
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "04_outputs" / "figures"
FIG.mkdir(parents=True, exist_ok=True)
PRED = ROOT / "04_outputs" / "predictions"
LOGS = ROOT / "04_outputs" / "logs"
INTERIM = ROOT / "01_data" / "interim"

plt.rcParams.update({
    "font.family": "Arial",
    "font.sans-serif": ["Arial"],
    "mathtext.fontset": "custom",
    "mathtext.rm": "Arial",
    "mathtext.it": "Arial:italic",
    "mathtext.bf": "Arial:bold",
    "axes.unicode_minus": False,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 9,
})
C_MAIN = "#2F5597"
C_ACC = "#C00000"
C_GRAY = "#7F7F7F"
C_LIGHT = "#DEEBF7"
C_ORANGE = "#ED7D31"
C_GREEN = "#548235"

MODELS = ["SVM", "LSTM", "XGBoost", "GRU", "TCN", "FCA-BiLSTM-HSK"]
CLASSES = ["Low", "Medium", "High"]


def save(fig, name):
    fig.savefig(FIG / f"{name}.png", bbox_inches="tight")
    fig.savefig(FIG / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)
    print("  saved", name)


# ------------------------------------------------------------------ Fig. 3
def fig3():
    cm = pd.read_csv(FIG.parent / "tables" / "confusion_matrix_median_seed.csv", index_col=0)
    ms = pd.read_csv(PRED / "metrics_summary.csv")
    fca = ms[ms.model == "FCA-BiLSTM-HSK"]
    med = fca[fca.seed == 3].iloc[0]
    knn = pd.read_csv(PRED / "knn_subset.csv")
    svm_only = (knn.y_true == knn.svm_pred).mean()
    final = (knn.y_true == knn.final_pred).mean()

    fig = plt.figure(figsize=(10.6, 3.4))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.15, 1.0], wspace=0.34)

    ax = fig.add_subplot(gs[0])
    mat = cm.to_numpy()
    ax.imshow(mat, cmap="Blues", vmin=0, vmax=mat.max())
    ax.set_xticks(range(3), CLASSES)
    ax.set_yticks(range(3), CLASSES)
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("True class")
    ax.xaxis.set_ticks_position("top")
    ax.xaxis.set_label_position("top")
    for i in range(3):
        for j in range(3):
            ax.text(j, i, str(mat[i, j]), ha="center", va="center",
                    color="white" if mat[i, j] > mat.max() * 0.55 else "#1F3864", fontsize=10)
    ax.set_title("(a) Confusion matrix (median seed, test set)", fontsize=9.5, pad=24)

    ax = fig.add_subplot(gs[1])
    metrics = ["Precision", "Recall", "F1"]
    vals = [[med.precision_L, med.recall_L, med.f1_L],
            [med.precision_M, med.recall_M, med.f1_M],
            [med.precision_H, med.recall_H, med.f1_H]]
    x = np.arange(3)
    w = 0.26
    for k, (cls, vv, c) in enumerate(zip(CLASSES, vals, [C_GRAY, C_ORANGE, C_ACC])):
        ax.bar(x + (k - 1) * w, np.array(vv) * 100, w, label=cls, color=c,
               edgecolor="white", linewidth=0.5)
        for xi, v in zip(x + (k - 1) * w, vv):
            ax.text(xi, v * 100 + 1.0, f"{v*100:.1f}", ha="center", fontsize=6.5)
    ax.set_xticks(x, metrics)
    ax.set_ylim(60, 104)
    ax.set_ylabel("Percent (%)")
    ax.set_title("(b) Per-class metrics (median seed)", fontsize=9.5)
    ax.legend(ncol=3, fontsize=7.5, loc="upper center", bbox_to_anchor=(0.5, -0.10),
              frameon=False)

    ax = fig.add_subplot(gs[2])
    n = len(knn)
    bars = ax.bar(["SVM only", "Cascade (KNN)"], [svm_only * 100, final * 100],
                  width=0.5, color=[C_GRAY, C_MAIN], edgecolor="white")
    for b, v, extra in zip(bars, [svm_only * 100, final * 100],
                           [f"{int(round(svm_only*n))}/{n}", f"{int(round(final*n))}/{n}"]):
        ax.text(b.get_x() + b.get_width() / 2, v + 1.5, f"{v:.1f}%\n({extra})",
                ha="center", fontsize=8)
    ax.set_ylim(55, 95)
    ax.set_ylabel("Subset accuracy (%)")
    ax.set_title("(c) KNN correction, low-confidence subset ($\\theta^*$=0.35)", fontsize=9.5)
    save(fig, "fig3_performance")


# ------------------------------------------------------------------ Fig. 4
def fig4():
    ms = pd.read_csv(PRED / "metrics_summary.csv")
    th = pd.read_csv(PRED / "theta_sensitivity.csv")
    fig, axes = plt.subplots(1, 3, figsize=(11.0, 3.4))
    colors = [C_GRAY, "#8FAADC", "#A9C47F", C_ORANGE, "#70AD47", C_MAIN]

    ax = axes[0]
    accs, stds = [], []
    for m in MODELS:
        sub = ms[ms.model == m]
        accs.append(sub.accuracy.mean() * 100)
        stds.append(sub.accuracy.std(ddof=1) * 100)
    bars = ax.bar(range(6), accs, yerr=stds, capsize=3, color=colors,
                  edgecolor="white", width=0.62, error_kw={"lw": 0.9})
    for b, v in zip(bars, accs):
        ax.text(b.get_x() + b.get_width() / 2, v + 1.4, f"{v:.1f}", ha="center", fontsize=7.5)
    ax.set_xticks(range(6), ["SVM", "LSTM", "XGBoost", "GRU", "TCN", "Ours"], fontsize=7.5)
    ax.set_ylim(80, 97)
    ax.set_ylabel("Test accuracy (%)")
    ax.set_title("(a) Model comparison", fontsize=9.5)

    ax = axes[1]
    # No hard-coded manuscript numbers: derive every bar and SD from Table 5.
    abdf=pd.read_csv(FIG.parent/'tables'/'table5_ablation.csv')
    variant_order=[('Bi-LSTM-SVM (baseline)','Base'),
                   ('w/o fuzzy-cloud features','w/o FC'),
                   ('w/o temporal attention','w/o Attn'),
                   ('w/o KNN cascade correction','w/o KNN'),
                   ('full model','Full model')]
    abl=[]
    for full_name,short_name in variant_order:
        raw=abdf.loc[abdf.variant==full_name,'accuracy']
        if len(raw)!=1: raise ValueError('Table 5 missing variant '+full_name)
        mean,sd=[float(a) for a in str(raw.iloc[0]).split('±')]
        abl.append((short_name,mean,sd))
    cols = [C_GRAY, "#A9C47F", "#8FAADC", "#70AD47", C_MAIN]
    bars = ax.bar(range(5), [a[1] for a in abl], yerr=[a[2] for a in abl], capsize=3,
                  color=cols, edgecolor="white", width=0.6, error_kw={"lw": 0.9})
    for b, a in zip(bars, abl):
        ax.text(b.get_x() + b.get_width() / 2, a[1] + a[2] + 0.45, f"{a[1]:.1f}", ha="center",
                fontsize=7.5)
    ax.set_xticks(range(5), [a[0] for a in abl], fontsize=7.5)
    ax.set_ylim(83, 95)
    ax.set_ylabel("Test accuracy (%)")
    ax.set_title("(b) Module ablation", fontsize=9.5)

    ax = axes[2]
    ax.plot(th.theta, th.accuracy_pct, "-o", color=C_MAIN, ms=4, lw=1.4)
    ax.axvline(0.35, ls="--", color=C_ACC, lw=1.0)
    ax.text(0.355, 91.62, "$\\theta^*$=0.35", color=C_ACC, fontsize=8)
    ax.set_xlabel("Routing threshold $\\theta$")
    ax.set_ylabel("Test accuracy (%)")
    ax.set_ylim(91.0, 93.2)
    ax.set_title("(c) Threshold sensitivity (median seed)", fontsize=9.5)
    fig.tight_layout(w_pad=2.2)
    save(fig, "fig4_comparison")


# ------------------------------------------------------------------ Fig. A1
def figA1():
    W = pd.read_csv(INTERIM / "windows.csv", dtype={"Stkcd": str})
    v = W[W.status == "valid"]
    order = ["vehicle", "battery", "components"]
    names = ["Vehicle", "Battery", "Components"]
    tr = [len(v[(v.industry == s) & (v.split == "train")]) for s in order]
    te = [len(v[(v.industry == s) & (v.split == "test")]) for s in order]
    lab2c = {"low": "L", "mid": "M", "high": "H"}
    test_labels = v[v.split == "test"].risk_label.map(lab2c).value_counts()

    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.2))
    ax = axes[0]
    x = np.arange(3)
    ax.bar(x, tr, 0.5, label="Training windows", color=C_MAIN, edgecolor="white")
    ax.bar(x, te, 0.5, bottom=tr, label="Test windows", color="#8FAADC", edgecolor="white")
    for i, (a, b) in enumerate(zip(tr, te)):
        ax.text(i, a / 2, str(a), ha="center", color="white", fontsize=9)
        ax.text(i, a + b / 2, str(b), ha="center", color="#1F3864", fontsize=9)
        ax.text(i, a + b + 22, f"{a+b}", ha="center", fontsize=9)
    ax.set_xticks(x, names)
    ax.set_ylabel("Number of windows")
    ax.set_title("(a) Window composition by segment", fontsize=9.5)
    ax.legend(frameon=False, fontsize=8.5)
    ax.set_ylim(0, 1180)

    ax = axes[1]
    vals = [test_labels.get("L", 0), test_labels.get("M", 0), test_labels.get("H", 0)]
    bars = ax.bar(["Low", "Medium", "High"], vals, color=[C_GRAY, C_ORANGE, C_ACC],
                  width=0.5, edgecolor="white")
    for b, v0 in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v0 + 10,
                f"{v0}\n({v0/sum(vals)*100:.1f}%)", ha="center", fontsize=8.5)
    ax.set_ylabel("Number of windows")
    ax.set_title("(b) Test-set class distribution", fontsize=9.5)
    ax.set_ylim(0, 760)
    fig.tight_layout(w_pad=2.4)
    save(fig, "figA1_sample")


# ------------------------------------------------------------------ Fig. A2
def figA2():
    runs = [("bilstm", "Bi-LSTM"), ("lstm", "LSTM"), ("gru", "GRU"), ("tcn", "TCN"),
            ("fc_bilstm", "FC-BiLSTM (no attention)"), ("fca_bilstm", "FCA-BiLSTM-HSK")]
    fig, ax = plt.subplots(figsize=(7.4, 3.6))
    colors = [C_GRAY, "#8FAADC", C_ORANGE, C_GREEN, "#A9C47F", C_MAIN]
    for (key, name), c in zip(runs, colors):
        df = pd.read_csv(LOGS / f"training_log_{key}_seed3.csv")
        ax.plot(df.epoch, df.val_loss, color=c, lw=1.2, label=name)
        best = df.loc[df.val_loss.idxmin()]
        ax.scatter(best.epoch, best.val_loss, s=16, color=c, zorder=5)
        ax.annotate(f"{int(best.epoch)}", (best.epoch, best.val_loss),
                    textcoords="offset points", xytext=(0, -9), ha="center",
                    fontsize=6.5, color=c)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Validation cross-entropy loss")
    ax.set_xlim(0, 202)
    ax.set_ylim(0.18, 0.62)
    ax.legend(ncol=2, fontsize=7.5, frameon=False, loc="upper right")
    fig.tight_layout()
    save(fig, "figA2_training")


# ------------------------------------------------------------------ Fig. 1
if __name__ == "__main__":
    print("Rendering figures ->", FIG)
    fig3()
    fig4()
    figA1()
    figA2()
    print("done")
