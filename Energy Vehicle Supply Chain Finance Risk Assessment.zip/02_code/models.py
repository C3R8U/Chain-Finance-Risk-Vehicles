# -*- coding: utf-8 -*-
"""Neural feature extractors and the paper's OvR-SVM / KNN cascade.

Shape contract: every backbone.forward(x) returns one (batch, features)
Tensor. Attention weights are available only with return_attn=True; this
avoids accidentally passing (features, attention) tuples to classification
heads. Risk codes 1, 2, 3 are mapped to zero-based targets only for neural
cross-entropy by the training driver.
"""
from __future__ import annotations

import numpy as np
from config import ATT_DIM, DROPOUT, HIDDEN, KNN_K, SVM_C, SVM_GAMMA


def _torch():
    try:
        import torch
        import torch.nn as nn
    except ImportError as exc:
        raise ImportError('PyTorch required for model training') from exc
    return torch, nn


def build_attention_bilstm(n_features: int, hidden: int = HIDDEN,
                           att_dim: int = ATT_DIM, dropout: float = DROPOUT,
                           use_attention: bool = True):
    """Bidirectional LSTM, with optional Eq.(15-17) temporal attention.

    No-attention ablation uses the concatenated terminal hidden states from
    both LSTM directions; it does not calculate attention scores.
    Dropout applies only to attention output, as specified for the head.
    """
    torch, nn = _torch()

    class AttentionBiLSTM(nn.Module):
        def __init__(self):
            super().__init__()
            self.use_attention = use_attention
            self.output_dim = 2 * hidden
            self.lstm = nn.LSTM(n_features, hidden, batch_first=True,
                                bidirectional=True)
            if use_attention:
                self.att_fc = nn.Linear(2 * hidden, att_dim)
                self.att_vec = nn.Parameter(torch.empty(att_dim))
                nn.init.normal_(self.att_vec, mean=0.0, std=0.1)
                self.drop = nn.Dropout(dropout)
            else:
                self.drop = nn.Identity()

        def forward(self, x, return_attn: bool = False):
            seq, (h_final, _) = self.lstm(x)
            if self.use_attention:
                u = torch.tanh(self.att_fc(seq))
                alpha = torch.softmax(u @ self.att_vec, dim=1)
                vec = torch.bmm(alpha.unsqueeze(1), seq).squeeze(1)
                vec = self.drop(vec)
            else:
                vec = torch.cat((h_final[-2], h_final[-1]), dim=1)
                alpha = None
            return (vec, alpha) if return_attn else vec

    return AttentionBiLSTM()


def build_sequence_baseline(kind: str, n_features: int,
                            hidden: int = HIDDEN):
    """LSTM/GRU baselines and residual, strictly causal TCN (64 channels).

    The TCN uses kernel size 3, dilation sequence (1,2,4,8), and skips via
    residual 1x1 projections. Left padding prevents using later time steps.
    """
    torch, nn = _torch()

    class CausalResidual(nn.Module):
        def __init__(self, in_channels: int, out_channels: int, dilation: int):
            super().__init__()
            self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=3,
                                  dilation=dilation, padding=0)
            self.left_pad = nn.ConstantPad1d((2 * dilation, 0), 0.0)
            self.skip = (nn.Identity() if in_channels == out_channels else
                         nn.Conv1d(in_channels, out_channels, kernel_size=1))
            self.activation = nn.ReLU()

        def forward(self, z):
            return self.activation(self.conv(self.left_pad(z)) + self.skip(z))

    class SeqBaseline(nn.Module):
        def __init__(self):
            super().__init__()
            self.kind = kind
            if kind == 'lstm':
                self.rnn = nn.LSTM(n_features, hidden, batch_first=True)
                self.output_dim = hidden
            elif kind == 'gru':
                self.rnn = nn.GRU(n_features, hidden, batch_first=True)
                self.output_dim = hidden
            elif kind == 'tcn':
                blocks = []
                in_channels = n_features
                for dilation in (1, 2, 4, 8):
                    blocks.append(CausalResidual(in_channels, 64, dilation))
                    in_channels = 64
                self.conv = nn.Sequential(*blocks)
                self.output_dim = 64
            else:
                raise ValueError(f'Unsupported backbone {kind!r}')

        def forward(self, x):
            if self.kind == 'tcn':
                return self.conv(x.transpose(1, 2))[:, :, -1]
            seq, _ = self.rnn(x)
            return seq[:, -1, :]

    return SeqBaseline()


class ClassifierHead:
    """Convenience module for direct neural baselines (not the HSK output)."""

    def __init__(self, backbone, n_features: int | None = None, n_classes=3,
                 hidden: int | None = None):
        torch, nn = _torch()
        self.torch = torch
        out_dim = int(hidden if hidden is not None else backbone.output_dim)
        self.backbone = backbone
        self.model = nn.Sequential(backbone, nn.Linear(out_dim, n_classes))

    def predict_proba(self, X):
        torch = self.torch
        self.model.eval()
        with torch.no_grad():
            logits = self.model(torch.as_tensor(X, dtype=torch.float32))
            return torch.softmax(logits, dim=1).cpu().numpy()

    def embed(self, X):
        torch = self.torch
        self.backbone.eval()
        with torch.no_grad():
            return self.backbone(torch.as_tensor(X, dtype=torch.float32)).cpu().numpy()


class SVMCascade:
    """Actual *one-vs-rest* RBF-SVM plus inverse-distance weighted KNN.

    A bare sklearn SVC(decision_function_shape='ovr') still trains a set of
    one-vs-one SVMs; the explicit OneVsRestClassifier is essential to match
    the one-vs-rest formulation in the manuscript. Scores are real margins
    from three independent binary RBF-SVMs, not probability surrogates.
    """

    def __init__(self, C: float = SVM_C, gamma: float = SVM_GAMMA,
                 k: int = KNN_K, theta: float = 0.35, seed: int = 1):
        from sklearn.multiclass import OneVsRestClassifier
        from sklearn.neighbors import KNeighborsClassifier
        from sklearn.svm import SVC
        self.svm = OneVsRestClassifier(SVC(C=C, gamma=gamma, kernel='rbf',
                                          probability=True, random_state=seed))
        self.knn = KNeighborsClassifier(n_neighbors=k, weights='distance')
        self.theta = float(theta)

    def fit(self, V, y):
        if len(V) < self.knn.n_neighbors:
            raise ValueError('fewer training observations than KNN neighbors')
        self.svm.fit(V, y)
        self.knn.fit(V, y)
        return self

    @staticmethod
    def margin(scores: np.ndarray) -> np.ndarray:
        scores = np.asarray(scores)
        if scores.ndim != 2 or scores.shape[1] < 2:
            raise ValueError('expected a 2D matrix of OvR class margins')
        ordered = np.sort(scores, axis=1)
        return ordered[:, -1] - ordered[:, -2]

    def predict(self, V, theta: float | None = None, use_knn: bool = True):
        theta = self.theta if theta is None else float(theta)
        scores = np.asarray(self.svm.decision_function(V))
        if scores.ndim == 1:
            scores = np.column_stack([-scores, scores])
        margin = self.margin(scores)
        svm_pred = self.svm.classes_[np.argmax(scores, axis=1)]
        knn_pred = self.knn.predict(V)
        pred = np.where(margin < theta, knn_pred, svm_pred) if use_knn else svm_pred
        return pred, margin, svm_pred, knn_pred

    def predict_proba(self, V, theta: float | None = None, use_knn: bool = True):
        theta = self.theta if theta is None else float(theta)
        scores = self.scores(V)
        route_knn = self.margin(scores) < theta
        proba = self.svm.predict_proba(V)
        if use_knn and route_knn.any():
            proba[route_knn] = self.knn.predict_proba(V[route_knn])
        return proba

    def scores(self, V):
        return np.asarray(self.svm.decision_function(V))
