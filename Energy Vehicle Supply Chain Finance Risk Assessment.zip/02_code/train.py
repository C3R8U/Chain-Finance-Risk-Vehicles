# -*- coding: utf-8 -*-
"""Train the models defined in the paper, without overwriting archived runs.

The official-source gate is enabled by default. `--data-mode legacy` is an
explicit retrospective replay only, NOT evidence of verified event labels.
Actual training generates checkpoint files and epoch logs with UTC timestamps.
There is no random-number interpolation of missing runs/results.

Usage (from package root):
  python 02_code/train.py --data-mode verified --stage main
  python 02_code/train.py --data-mode verified --stage ablation
  python 02_code/train.py --data-mode legacy --stage main
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score

import config as C
from cloud_features import cloud_panel
from evaluate import class_report, macro_auc, average_precision_high
from models import SVMCascade, _torch, build_attention_bilstm, build_sequence_baseline

sys.path.insert(0, str(C.ROOT / '01_data'))
from preprocess import q_index

DATA_PATH = {
    'legacy': C.ROOT / '01_data' / 'interim',
    'verified': C.ROOT / '01_data' / 'verified_candidate',
}

# Study's Table 5: same training/validation split, one module removed per row.
MODEL_VARIANTS = {
    'fca_bilstm': dict(cloud=True, attention=True, knn=True),
    'no_fuzzy_cloud': dict(cloud=False, attention=True, knn=True),
    'no_temporal_attention': dict(cloud=True, attention=False, knn=True),
    'no_knn': dict(cloud=True, attention=True, knn=False),
    'basic_bilstm_svm': dict(cloud=False, attention=False, knn=False),
}
NETWORK_BASELINES = {'lstm', 'gru', 'tcn'}
CLASSICAL_BASELINES = {'svm', 'xgboost'}


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def load_windows(data_mode: str):
    directory = DATA_PATH[data_mode]
    if data_mode == 'verified':
        from source_audit import validate, validate_coverage
        validate('st_status_verified.csv')
        validate('commercial_paper_verified.csv')
        issues=validate_coverage()
        if issues:
            raise ValueError(f'Official source candidate review incomplete: {len(issues)} items')
    if not (directory / 'window_tensor.npz').is_file():
        raise FileNotFoundError(f'Missing {directory}/window_tensor.npz; build_data.py --label-mode {data_mode} first')
    arr = np.load(directory / 'window_tensor.npz', allow_pickle=True)
    W = pd.read_csv(directory / 'windows.csv', dtype={'Stkcd': str})
    W = W[W.status == 'valid'].reset_index(drop=True)
    X = np.asarray(arr['X'], dtype=np.float32)
    y = np.asarray(arr['y'], dtype=np.int64)
    if len(W) != len(X) or len(y) != len(X):
        raise ValueError('Window labels and feature tensor are misaligned')
    if not set(np.unique(y)).issubset({1, 2, 3}):
        raise ValueError('Expected manuscript risk codes {1,2,3}')
    return X, y, W, arr['quarters'], list(arr['features'])


def rolling_cloud(X: np.ndarray, length=4):
    """Causal Ex/En/He at each step, using <=4 available historical steps.

    The first time step of an 8-quarter window has one observed quarter;
    its cloud is (x, 0, 0). No future quarters are borrowed to fill history.
    At later steps use the sample-variance, absolute-deviation entropy and
    nonnegative He formulas in the paper.
    """
    X = np.asarray(X, dtype=float)
    n, t, f = X.shape
    out = np.empty((n, t, 3 * f), dtype=np.float32)
    for step in range(t):
        sub = X[:, max(0, step-length+1):step+1, :]
        if sub.shape[1] == 1:
            out[:, step, 0::3] = sub[:, 0, :]
            out[:, step, 1::3] = 0.0
            out[:, step, 2::3] = 0.0
        else:
            for i in range(n):
                out[i, step] = cloud_panel(sub[i].T[None, :, :])[0]
    if not np.isfinite(out).all():
        raise ValueError('Non-finite cloud features: verify input tensor and missing-value handling')
    return out


def standardize(X: np.ndarray, mask: np.ndarray):
    if not mask.any():
        raise ValueError('No fit observations; cannot standardize')
    ref = np.asarray(X[mask], dtype=np.float64).reshape(-1, X.shape[-1])
    mu, sd = ref.mean(0), ref.std(0)
    sd[sd < 1e-12] = 1.0
    normalized = ((X - mu) / sd).astype(np.float32)
    if not np.isfinite(normalized).all():
        raise ValueError('Standardisation produced NaNs or infinities')
    return normalized


def set_seed(seed: int):
    torch, _ = _torch()
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


def train_backbone(kind: str, X: np.ndarray, y: np.ndarray, fit, val,
                   seed: int, output: Path, epochs: int | None = None):
    """Real optimization on 0..2 targets, with all epochs and weights saved."""
    torch, nn = _torch()
    set_seed(seed)
    if kind in MODEL_VARIANTS:
        p = MODEL_VARIANTS[kind]
        backbone = build_attention_bilstm(X.shape[-1], use_attention=p['attention'])
    elif kind in NETWORK_BASELINES:
        backbone = build_sequence_baseline(kind, X.shape[-1])
    else:
        raise ValueError(kind)
    classifier = nn.Sequential(backbone, nn.Linear(backbone.output_dim, 3))
    optimizer = torch.optim.Adam(classifier.parameters(), lr=C.LR,
                                 weight_decay=C.WEIGHT_DECAY)
    criterion = nn.CrossEntropyLoss()
    fit_X = torch.as_tensor(X[fit], dtype=torch.float32)
    val_X = torch.as_tensor(X[val], dtype=torch.float32)
    fit_y = torch.as_tensor(y[fit]-1, dtype=torch.long)  # critical 1-based -> 0-based
    val_y = torch.as_tensor(y[val]-1, dtype=torch.long)
    assert fit_y.min().item() >= 0 and fit_y.max().item() <= 2
    best_loss, best_state, wait, best_epoch = float('inf'), None, 0, 0
    entries = []
    started = time.monotonic()
    run_id = f'{kind}_seed{seed}_{datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")}'
    n_epochs = C.MAX_EPOCH if epochs is None else int(epochs)
    for epoch in range(1, n_epochs+1):
        classifier.train()
        total = 0.0
        for group in torch.randperm(len(fit_X)).split(C.BATCH):
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(classifier(fit_X[group]), fit_y[group])
            loss.backward()
            optimizer.step()
            total += loss.detach().item() * group.numel()
        classifier.eval()
        with torch.no_grad():
            logits = classifier(val_X)
            val_loss = criterion(logits, val_y).item()
            val_acc = (logits.argmax(1) == val_y).float().mean().item()
        improved = val_loss < best_loss-1e-6
        if improved:
            best_epoch, best_loss, wait = epoch, val_loss, 0
            best_state = {key: val.detach().cpu().clone()
                          for key, val in classifier.state_dict().items()}
        else:
            wait += 1
        stop = wait >= C.PATIENCE
        entries.append({
            'run_id': run_id, 'config': kind, 'seed': seed, 'epoch': epoch,
            'train_loss': total/len(fit_X), 'val_loss': val_loss,
            'val_acc': val_acc, 'timestamp_utc': utcnow(),
            'elapsed_seconds': round(time.monotonic()-started, 4),
            'early_stopped': stop,
        })
        if stop:
            break
    classifier.load_state_dict(best_state)
    classifier.eval()
    for m in classifier.modules():
        if isinstance(m, nn.Dropout):
            assert not m.training
    output.mkdir(parents=True, exist_ok=True)
    log_path = output / f'{kind}_seed{seed}_epochs.csv'
    weights_path = output / f'{kind}_seed{seed}_checkpoint.pt'
    pd.DataFrame(entries).to_csv(log_path, index=False, encoding='utf-8-sig')
    torch.save({'state_dict': classifier.state_dict(),
                'model_kind': kind, 'seed': seed, 'best_epoch': best_epoch,
                'feature_dim': X.shape[-1], 'fit_n': int(fit.sum()),
                'validation_n': int(val.sum()), 'timestamp_utc': utcnow()},
               weights_path)
    return classifier, backbone, {
        'run_id': run_id, 'best_epoch': best_epoch, 'epochs_completed': len(entries),
        'min_validation_loss': best_loss, 'checkpoint_sha256': sha256(weights_path),
        'epoch_log_sha256': sha256(log_path),
    }


def representation(backbone, X: np.ndarray):
    torch, _ = _torch()
    backbone.eval()
    with torch.no_grad():
        return backbone(torch.as_tensor(X, dtype=torch.float32)).cpu().numpy()


def baseline_probabilities(kind: str, xtr, ytr, xva, xte, seed):
    """Fixed hyperparameters of manuscript Table 3; no invented Bayes-search logs.

    Reproducing the stated *50-round Bayesian optimization* would additionally
    require the original search space / objective / trial histories, which
    are not present in the supplied materials. This computes valid predictions
    with the paper's frozen baseline values, not a false optimization history.
    """
    if kind == 'svm':
        from sklearn.multiclass import OneVsRestClassifier
        from sklearn.svm import SVC
        model = OneVsRestClassifier(SVC(C=C.SVM_C, gamma=C.SVM_GAMMA,
                                        kernel='rbf', probability=True,
                                        random_state=seed))
        model.fit(xtr, ytr)
        return model.predict_proba(xva), model.predict_proba(xte), model
    if kind == 'xgboost':
        import xgboost as xgb
        model = xgb.XGBClassifier(n_estimators=200, max_depth=6,
                                  learning_rate=0.05, subsample=0.8,
                                  colsample_bytree=0.8,
                                  objective='multi:softprob',
                                  num_class=3, random_state=seed,
                                  n_jobs=1, eval_metric='mlogloss')
        model.fit(xtr, ytr-1)
        return model.predict_proba(xva), model.predict_proba(xte), model
    raise ValueError(kind)


def run(stage: str, data_mode: str, epochs: int | None = None,
        seeds: list[int] | None = None, only_models: list[str] | None = None):
    X, y, W, quarters, features = load_windows(data_mode)
    end = W['win_end_quarter'].map(q_index).to_numpy()
    train = (W.split == 'train').to_numpy()
    test = (W.split == 'test').to_numpy()
    val = train & (end >= q_index(C.VAL_START_Q))
    fit = train & ~val
    if min(int(fit.sum()), int(val.sum()), int(test.sum())) < 1:
        raise RuntimeError('Train/validation/test time masks are empty')
    raw = standardize(X, fit)
    cloud = standardize(rolling_cloud(X, length=4), fit)
    variants = (['fca_bilstm','svm','lstm','xgboost','gru','tcn']
                if stage=='main' else
                ['basic_bilstm_svm','no_fuzzy_cloud','no_temporal_attention',
                 'no_knn','fca_bilstm'])
    if only_models is not None:
        invalid=set(only_models)-set(variants)
        if invalid:
            raise ValueError(f'Models not part of the requested stage: {sorted(invalid)}')
        variants=only_models
    if seeds is None:
        seeds=C.SEEDS
    if not seeds or any(int(s) not in C.SEEDS for s in seeds):
        raise ValueError('Seed must be in the fixed 1..5 study seed set')
    # A new training run is isolated from the historical result snapshot.
    output = C.OUT / 'retrained' / data_mode / stage
    logs = output / 'logs'
    logs.mkdir(parents=True, exist_ok=True)
    pred_rows, metric_rows, theta_rows, manifests = [], [], [], []
    for kind in variants:
        use_cloud = MODEL_VARIANTS.get(kind, {}).get('cloud', False)
        Xseq = cloud if use_cloud else raw
        for seed in seeds:
            set_seed(seed)
            if kind in CLASSICAL_BASELINES:
                baseline_start=utcnow()
                va_p, te_p, fitted_baseline = baseline_probabilities(
                    kind, raw[fit].reshape(fit.sum(),-1), y[fit],
                    raw[val].reshape(val.sum(),-1), raw[test].reshape(test.sum(),-1), seed)
                y_va, y_te = va_p.argmax(1)+1, te_p.argmax(1)+1
                margins = np.full(test.sum(), np.nan)
                svm_te, knn_te = y_te.copy(), y_te.copy()
                import joblib
                model_file=logs/f'{kind}_seed{seed}_fitted.joblib'
                joblib.dump(fitted_baseline,model_file,compress=3)
                metadata_file=logs/f'{kind}_seed{seed}_training.json'
                metadata_file.write_text(json.dumps({
                    'model':kind,'seed':seed,'fit_started_utc':baseline_start,
                    'fit_finished_utc':utcnow(), 'fit_windows':int(fit.sum()),
                    'validation_windows':int(val.sum()),
                    'test_windows':int(test.sum()),
                    'fixed_parameters':fitted_baseline.get_params(deep=False),
                    'source':'actual local sklearn or xgboost fit; no Bayesian trial log claimed'
                },ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                meta = {'run_id':f'{kind}_seed{seed}', 'best_epoch':None,
                        'epochs_completed':None, 'checkpoint_sha256':sha256(model_file),
                        'epoch_log_sha256':None,
                        'fit_metadata_sha256':sha256(metadata_file)}
            else:
                classifier, backbone, meta = train_backbone(
                    kind, Xseq, y, fit, val, seed, logs, epochs=epochs)
                if kind in MODEL_VARIANTS:
                    p = MODEL_VARIANTS[kind]
                    Zfit, Zval, Ztest = (representation(backbone, Xseq[m])
                                         for m in (fit, val, test))
                    cascade = SVMCascade(seed=seed).fit(Zfit, y[fit])
                    _, va_margin, va_svm, va_knn = cascade.predict(Zval, theta=0.0)
                    _, margins, svm_te, knn_te = cascade.predict(Ztest, theta=0.0)
                    if p['knn']:
                        valid_theta = []
                        for theta in C.THETA_GRID:
                            y_hat = np.where(va_margin < theta, va_knn, va_svm)
                            score = accuracy_score(y[val], y_hat)
                            theta_rows.append({'config':kind,'seed':seed,'theta':theta,
                                               'split':'validation','accuracy':score})
                            valid_theta.append((score, theta))
                        # deterministic ties: smallest theta among max scores
                        validation_best_theta = sorted(valid_theta, key=lambda item: (-item[0],item[1]))[0][1]
                        # Paper Table 3: the validated routing threshold is
                        # frozen at 0.35 for test. Record if new validation
                        # labels would select a different optimum; never
                        # silently choose a threshold on the test set.
                        best_theta = C.THETA_STAR
                    else:
                        validation_best_theta = None
                        best_theta = 0.0
                    y_va = np.where(va_margin<best_theta,va_knn,va_svm)
                    y_te = np.where(margins<best_theta,knn_te,svm_te)
                    te_p = cascade.predict_proba(Ztest,theta=best_theta,
                                                 use_knn=p['knn'])
                    for theta in C.THETA_GRID:
                        yh = np.where(margins<theta,knn_te,svm_te) if p['knn'] else svm_te
                        theta_rows.append({'config':kind,'seed':seed,'theta':theta,
                                           'split':'test','accuracy':accuracy_score(y[test],yh),
                                           'low_conf_n':int((margins<theta).sum())})
                    meta['theta'] = best_theta
                    meta['validation_optimal_theta'] = validation_best_theta
                else:
                    torch,_=_torch()
                    with torch.no_grad():
                        classifier.eval()
                        va_p=torch.softmax(classifier(torch.as_tensor(Xseq[val])),dim=1).cpu().numpy()
                        te_p=torch.softmax(classifier(torch.as_tensor(Xseq[test])),dim=1).cpu().numpy()
                    y_va,y_te=va_p.argmax(1)+1,te_p.argmax(1)+1
                    margins=np.full(test.sum(),np.nan)
                    svm_te,knn_te=y_te.copy(),y_te.copy()
            report=class_report(y[test],y_te)
            report.update({'model':kind,'seed':seed,'data_mode':data_mode,
                           'val_accuracy':accuracy_score(y[val],y_va),
                           'macro_auc':macro_auc(y[test],te_p),
                           'ap_high':average_precision_high(y[test],te_p)})
            metric_rows.append(report)
            manifest={'model':kind,'seed':seed,'data_mode':data_mode,
                      'fit_windows':int(fit.sum()),'validation_windows':int(val.sum()),
                      'test_windows':int(test.sum()),**meta}
            manifests.append(manifest)
            pred_rows.append(pd.DataFrame({
                'Stkcd':W.loc[test,'Stkcd'].to_numpy(),
                'win_index':W.loc[test,'win_index'].to_numpy(),
                'end_quarter':W.loc[test,'win_end_quarter'].to_numpy(),
                'y_true':y[test], 'y_pred':y_te,
                'y_svm':svm_te,'y_knn':knn_te,'margin':margins,
                'p_low':te_p[:,0], 'p_mid':te_p[:,1],'p_high':te_p[:,2],
                'model':kind,'seed':seed,'data_mode':data_mode,
            }))
            print(f'{kind} seed {seed}: accuracy={report["accuracy"]:.4f}, '
                  f'val_accuracy={report["val_accuracy"]:.4f}')
    pd.concat(pred_rows,ignore_index=True).to_csv(output/'predictions.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(metric_rows).to_csv(output/'metrics.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(theta_rows).to_csv(output/'theta_validation.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(manifests).to_csv(output/'run_manifest.csv',index=False,encoding='utf-8-sig')
    (output/'model_settings.json').write_text(json.dumps({
        'label_mode':data_mode,'stage':stage,'start_quarter':C.START_Q,
        'end_quarter':C.END_Q,'seeds':seeds,'max_epochs':epochs or C.MAX_EPOCH,
        'patience':C.PATIENCE,'learning_rate':C.LR,'batch_size':C.BATCH,
        'weight_decay':C.WEIGHT_DECAY,'dropout':C.DROPOUT,
        'SVM_C':C.SVM_C,'SVM_gamma':C.SVM_GAMMA,'KNN_k':C.KNN_K,
        'theta_grid':C.THETA_GRID,'features':features,
        'source_data_tensor_sha256':sha256(DATA_PATH[data_mode]/'window_tensor.npz'),
        'created_utc':utcnow(),
    },ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['main','ablation'],default='main')
    parser.add_argument('--data-mode',choices=['verified','legacy'],default='verified')
    parser.add_argument('--epochs',type=int,default=None,
                        help='For implementation tests only; never represent short runs as original 200-epoch experiments')
    parser.add_argument('--seeds',type=int,nargs='+',default=None,
                        help='Subset is for diagnostic runs only; publication results require all 5')
    parser.add_argument('--models',nargs='+',default=None,
                        help='Subset is for diagnostic runs only')
    a=parser.parse_args()
    run(a.stage,a.data_mode,a.epochs,a.seeds,a.models)
