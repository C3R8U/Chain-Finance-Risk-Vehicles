# -*- coding: utf-8 -*-
"""Global configuration: paths, sample period, window parameters, model
hyperparameters and random seeds.

All sources of randomness are declared here and read by the training,
calibration and evaluation scripts so that per-seed results remain
comparable.
"""
from pathlib import Path

# ---------- paths ----------
ROOT = Path(__file__).resolve().parent.parent
DATA_RAW = ROOT / "01_data" / "raw"          # CNEquity/AKShare extraction data (shipped with the package)
DATA_INT = ROOT / "01_data" / "interim"      # intermediate panel
OUT = ROOT / "04_outputs"
OUT_TABLES = OUT / "tables"
OUT_FIGS = OUT / "figures"
OUT_PRED = OUT / "predictions"
OUT_LOGS = OUT / "logs"
for _p in (DATA_INT, OUT_TABLES, OUT_FIGS, OUT_PRED, OUT_LOGS):
    _p.mkdir(parents=True, exist_ok=True)

# ---------- sample and windows ----------
START_Q = "2018Q1"
END_Q = "2023Q4"
WINDOW_T = 8          # window length (quarters)
WINDOW_S = 1          # step (quarters)
TRAIN_END_Q = "2021Q4"   # training windows end no later than this quarter
TEST_START_Q = "2022Q1"  # test windows end no earlier than this quarter
VAL_START_Q = "2021Q1"   # validation segment at the end of training: windows ending in [VAL_START_Q, TRAIN_END_Q]

# ---------- labels ----------
RISK_ORDER = ["low", "mid", "high"]
RISK_CODE = {"low": 1, "mid": 2, "high": 3}

# ---------- models ----------
SEEDS = [1, 2, 3, 4, 5]
HIDDEN = 128
ATT_DIM = 64
LR = 1e-3
BATCH = 32
MAX_EPOCH = 200
PATIENCE = 20          # early-stopping patience (stop after PATIENCE epochs without validation-loss improvement)
WEIGHT_DECAY = 1e-5
DROPOUT = 0.2

SVM_C = 10.0
SVM_GAMMA = 0.05
KNN_K = 5
THETA_GRID = [round(0.10 + 0.05 * i, 2) for i in range(11)]  # 0.10~0.60
THETA_STAR = 0.35       # frozen after validation calibration; consistent with Section 4.3 and numbers.json

# ---------- evaluation ----------
N_BOOT = 1000          # firm-cluster bootstrap replications
N_PERM = 1000          # permutation-test replications
BOOT_SEED = 20261105

# ---------- Table 3 hardware (written to the paper; overridable at runtime) ----------
HARDWARE = {
    "cpu": "Intel Core i9-12900K",
    "gpu": "NVIDIA GeForce RTX 3090",
    "ram": "64 GB DDR4",
    "os": "Ubuntu 20.04 LTS",
    "framework": "PyTorch 1.10 / Python 3.8",
}
