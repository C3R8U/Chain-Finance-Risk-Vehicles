# -*- coding: utf-8 -*-
"""Recompute every manuscript figure/table value from the shipped result
files, and generate the appendix tables.

Inputs (read-only): 04_outputs/predictions/*.csv, 01_data/interim/events_firm_quarter.csv
Outputs: 04_outputs/tables/*.csv, 04_outputs/numbers.json

Design rule: every number that enters the manuscript must be recomputable
value-by-value from the files in this package; no uncomputed placeholder is
ever written.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
# result sources: 04_outputs/predictions (author-run outputs shipped with the package)
RES = ROOT / "04_outputs" / "predictions"
TAB = ROOT / "04_outputs" / "tables"
TAB.mkdir(parents=True, exist_ok=True)

RNG = np.random.default_rng(20240501)
N_BOOT = 1000
LAB = ["L", "M", "H"]
NUM = {"L": 1, "M": 2, "H": 3}


def pct(x, nd=1):
    return round(float(x) * 100, nd)


def wilson(k, n, z=1.959963985):
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - h) / d, (c + h) / d


def qwk(y1, y2, labels=(1, 2, 3)):
    n = len(y1)
    k = len(labels)
    idx = {v: i for i, v in enumerate(labels)}
    O = np.zeros((k, k))
    for a, b in zip(y1, y2):
        O[idx[a], idx[b]] += 1
    w = np.array([[(i - j) ** 2 / (k - 1) ** 2 for j in range(k)] for i in range(k)])
    h1 = O.sum(1)
    h2 = O.sum(0)
    E = np.outer(h1, h2) / n
    return 1 - (w * O).sum() / (w * E).sum()


def adj_stats(y_true, y_pred, labels=(1, 2, 3)):
    """Adjacent-misclassification share, random-guess baseline, and their difference."""
    yt = np.asarray(y_true)
    yp = np.asarray(y_pred)
    wrong = yt != yp
    d = np.abs(yt - yp)
    adj = int((wrong & (d == 1)).sum())
    far = int((wrong & (d == 2)).sum())
    share = adj / max(int(wrong.sum()), 1)
    # random baseline: predictions drawn independently from the class marginals
    marg = np.array([(yt == c).mean() for c in labels])
    exp_adj = exp_wrong = 0.0
    for c, pc in zip(labels, marg):
        for c2, p2 in zip(labels, marg):
            if c2 != c:
                exp_wrong += pc * p2
                if abs(c2 - c) == 1:
                    exp_adj += pc * p2
    base = exp_adj / exp_wrong
    return dict(n=int(len(yt)), wrong=int(wrong.sum()), adj=adj, far=far,
                share=share, base=base, diff=share - base,
                kappa=qwk(yt, yp))


def cluster_boot_ci(firms, values, stat_fn, n_boot=N_BOOT, rng=RNG):
    """Resample at the firm level (cluster bootstrap)."""
    firms = np.asarray(firms)
    uniq = np.unique(firms)
    pos = {f: np.where(firms == f)[0] for f in uniq}
    out = []
    for _ in range(n_boot):
        pick = rng.choice(uniq, size=len(uniq), replace=True)
        idx = np.concatenate([pos[f] for f in pick])
        out.append(stat_fn(idx))
    out = np.asarray(out, dtype=float)
    return np.nanpercentile(out, 2.5), np.nanpercentile(out, 97.5)


def main():
    ws = pd.read_csv(RES / "window_split.csv")
    pred = pd.read_csv(RES / "predictions_all.csv")
    msum = pd.read_csv(RES / "metrics_summary.csv")
    knn = pd.read_csv(RES / "knn_subset.csv")
    ev = pd.read_csv(ROOT / "01_data" / "interim" / "events_firm_quarter.csv")

    nums = {}

    # ---------------- Table 2 sample composition ----------------
    seg_name = {"vehicle": "Vehicle Manufacturing", "battery": "Power Battery", "components": "Core Components"}
    g = ws.groupby("industry")
    t2 = pd.DataFrame({
        "segment": [seg_name[k] for k in g.size().index],
        "firms": g.firm_id.nunique().values,
        "candidate": g.size().values,
        "excluded": g.apply(lambda d: (d.status != "valid").sum()).values,
        "valid": g.apply(lambda d: (d.status == "valid").sum()).values,
        "train": g.apply(lambda d: (d.split == "train").sum()).values,
        "test": g.apply(lambda d: (d.split == "test").sum()).values,
    })
    tot = pd.DataFrame([{
        "segment": "Total", "firms": ws.firm_id.nunique(),
        "candidate": len(ws), "excluded": int((ws.status != "valid").sum()),
        "valid": int((ws.status == "valid").sum()),
        "train": int((ws.split == "train").sum()),
        "test": int((ws.split == "test").sum())}])
    t2 = pd.concat([t2, tot], ignore_index=True)
    t2.to_csv(TAB / "table2_sample.csv", index=False, encoding="utf-8-sig")

    for i, row in t2.iterrows():
        k = f"T2_SEG{i+1}" if i < 3 else "T2_ALL"
        nums[k + "_FIRMS"] = int(row.firms)
        nums[k + "_CAND"] = int(row.candidate)
        nums[k + "_REMOVED"] = int(row.excluded)
        nums[k + "_VALID"] = int(row.valid)
        nums[k + "_TRAIN"] = int(row.train)
        nums[k + "_TEST"] = int(row.test)

    nums["N_FIRMS"] = int(ws.firm_id.nunique())
    nums["N_CAND"] = int(len(ws))
    nums["N_REMOVED"] = int((ws.status != "valid").sum())
    nums["N_WINDOWS"] = int((ws.status == "valid").sum())
    nums["N_TRAIN"] = int((ws.split == "train").sum())
    nums["N_TEST"] = int((ws.split == "test").sum())

    v = ws[ws.status == "valid"]
    for lab, key in (("L", "LOW"), ("M", "MID"), ("H", "HIGH")):
        nums[f"CL_{key}"] = int((v.risk_label == lab).sum())
        nums[f"CL_{key}_P"] = pct((v.risk_label == lab).mean())
    vt = v[v.split == "test"]
    for lab, key in (("L", "LOW"), ("M", "MID"), ("H", "HIGH")):
        nums[f"TL_{key}"] = int((vt.risk_label == lab).sum())
        nums[f"TL_{key}_P"] = pct((vt.risk_label == lab).mean())

    # ---------------- window overlap ----------------
    def qidx(q):
        y, k = q.split("Q")
        return int(y) * 4 + int(k)

    tr = v[v.split == "train"]
    te = v[v.split == "test"]
    tr_q = {}
    for f, s, e in zip(tr.firm_id, tr.win_start_quarter, tr.win_end_quarter):
        tr_q.setdefault(f, []).append((qidx(s), qidx(e)))
    ov, mx = 0, 0
    for f, s, e in zip(te.firm_id, te.win_start_quarter, te.win_end_quarter):
        a, b = qidx(s), qidx(e)
        if f in tr_q:
            cand = 0
            for c, d in tr_q[f]:
                cand = max(cand, min(b, d) - max(a, c) + 1)
            if cand > 0:
                ov += 1
                mx = max(mx, cand)
    nums["N_OVERLAP"] = int(ov)
    nums["MAX_OVERLAP"] = int(mx)

    # ---------------- main-model seed summary ----------------
    fca = msum[msum.model == "FCA-BiLSTM-HSK"].sort_values("seed")
    seeds = ["1", "2", "3", "4", "5"]
    accs = fca.accuracy.values
    med_i = int(np.argsort(accs)[len(accs) // 2])
    med_seed = int(fca.seed.values[med_i])
    nums["MEDIAN_SEED"] = med_seed
    nums["ACC"] = pct(accs.mean())
    nums["ACC_SD"] = pct(accs.std(ddof=1))

    def m_sd(col):
        return pct(fca[col].mean()), pct(fca[col].std(ddof=1))

    for col, key in (("precision_H", "HP"), ("recall_H", "HR"), ("f1_H", "HF1"),
                     ("macro_f1", "F1"), ("weighted_f1", "WF1")):
        m, s = m_sd(col)
        nums[key] = m
        nums[key + "_SD"] = s

    mid = fca[fca.seed == med_seed].iloc[0]
    for col, key in (("accuracy", "ACC_MED"), ("weighted_f1", "F1_MED"),
                     ("precision_H", "HP_MED"), ("recall_H", "HR_MED"),
                     ("f1_H", "HF1_MED")):
        nums[key] = pct(mid[col])

    nums["AUC"] = round(float(fca.macro_auc.mean()), 3)
    nums["AUC_SD"] = round(float(fca.macro_auc.std(ddof=1)), 3)
    nums["AP"] = round(float(fca.ap_high.mean()), 3)

    # ---------------- main model per-window: confusion, tests ----------------
    m = pred[(pred.model == "FCA-BiLSTM-HSK") & (pred.seed == med_seed)].copy()
    yt = m.y_true.map(NUM).to_numpy()
    yp = m.y_pred.map(NUM).to_numpy()

    conf = pd.crosstab(pd.Categorical(m.y_true, LAB), pd.Categorical(m.y_pred, LAB)).reindex(
        index=LAB, columns=LAB, fill_value=0)
    conf.to_csv(TAB / "confusion_matrix_median_seed.csv", encoding="utf-8-sig")
    nums["K_HIGH"] = int(conf.loc["H", "H"])
    nums["MISS_MID"] = int(conf.loc["H", "M"])
    nums["MISS_LOW"] = int(conf.loc["H", "L"])
    nums["N_HIGH_TEST"] = int((m.y_true == "H").sum())
    nums["N_HIGH_FIRMS"] = int(m[m.y_true == "H"].firm_id.nunique())

    k, n = nums["K_HIGH"], nums["N_HIGH_TEST"]
    lo, hi = wilson(k, n)
    nums["WILSON_LO"], nums["WILSON_HI"] = pct(lo), pct(hi)

    firms = m.firm_id.to_numpy()
    hr = lambda idx: (yt[idx] == 3)[(yp[idx] == 3)].sum() / max((yt[idx] == 3).sum(), 1)
    lo2, hi2 = cluster_boot_ci(firms, None, hr)
    nums["HR_CI_LO"], nums["HR_CI_HI"] = pct(lo2), pct(hi2)

    a = adj_stats(yt, yp)
    nums.update({"N_WRONG": a["wrong"], "ADJ_SHARE": pct(a["share"]),
                 "FAR_SHARE": pct(a["far"] / a["wrong"]), "N_FAR": a["far"],
                 "ADJ_BASE": pct(a["base"]), "ADJ_DIFF": round(a["diff"] * 100, 1),
                 "KAPPA": round(a["kappa"], 3)})
    lo3, hi3 = cluster_boot_ci(
        firms, None,
        lambda idx: adj_stats(yt[idx], yp[idx])["share"] - adj_stats(yt[idx], yp[idx])["base"])
    nums["ADJ_LO"], nums["ADJ_HI"] = round(lo3 * 100, 1), round(hi3 * 100, 1)

    # ---------------- tests against TCN ----------------
    tcn = pred[(pred.model == "TCN") & (pred.seed == med_seed)][
        ["firm_id", "win_index", "y_pred"]]
    mm = m[["firm_id", "win_index"]].merge(
        tcn, on=["firm_id", "win_index"], how="left", validate="one_to_one")
    assert len(mm) == len(m), "TCN predictions do not align one-to-one with main-model windows"
    yp_b = mm.y_pred.map(NUM).to_numpy()
    # b: proposed model correct & TCN wrong; c: proposed model wrong & TCN correct
    b = int(((yp == yt) & (yp_b != yt)).sum())
    c = int(((yp != yt) & (yp_b == yt)).sum())
    chi2 = (abs(b - c) - 1) ** 2 / (b + c)
    nums.update({"MC_B": b, "MC_C": c, "MC_CHI2": round(chi2, 1)})

    # Independent reproducible company-cluster bootstrap from 1102 paired rows.
    # The supplied author CI file has no bootstrap draw-level provenance and
    # is preserved separately in 05_docs/original_snapshots/; never copy it.
    pair = m[['firm_id','win_index','y_true','y_pred']].merge(
        pred[(pred.model == 'TCN') & (pred.seed == med_seed)][
            ['firm_id','win_index','y_true','y_pred']],
        on=['firm_id','win_index'], how='inner',
        suffixes=('_fca','_tcn'),validate='one_to_one')
    assert len(pair)==len(m) and (pair.y_true_fca==pair.y_true_tcn).all()
    correct_fca=(pair.y_true_fca==pair.y_pred_fca).to_numpy().astype(int)
    correct_tcn=(pair.y_true_fca==pair.y_pred_tcn).to_numpy().astype(int)
    diffs=correct_fca-correct_tcn
    groups=pair.firm_id.to_numpy()
    companies=np.unique(groups)
    group_pos={g:np.where(groups==g)[0] for g in companies}
    bootstrap_rng=np.random.default_rng(20261105)
    boot=[]
    for _ in range(N_BOOT):
        draw=bootstrap_rng.choice(companies,size=len(companies),replace=True)
        idx=np.concatenate([group_pos[f] for f in draw])
        boot.append(diffs[idx].mean()*100)
    ci0,ci1=np.percentile(boot,[2.5,97.5])
    from math import erfc, sqrt
    pv=erfc(sqrt(chi2/2))
    pd.DataFrame([dict(b=b,c=c,chi2=chi2,p_value=pv,
        delta_acc_pp=diffs.mean()*100,boot_lower_pp=ci0,
        boot_upper_pp=ci1,n_boot=N_BOOT,bootstrap_seed=20261105,
        bootstrap_unit='firm_id',confidence_interval='percentile_2.5_97.5')]).to_csv(
            RES/'mcnemar_bootstrap.csv',index=False,encoding='utf-8-sig')
    nums['DIFF_TCN']=round(float(diffs.mean()*100),1)
    nums['DIFF_CI_LO']=round(float(ci0),1)
    nums['DIFF_CI_HI']=round(float(ci1),1)
    assert b-c==int(diffs.sum()) and int(diffs.sum())==40

    # ---------------- baseline comparison ----------------
    name_map = {"SVM": "SVM", "LSTM": "LSTM", "XGBoost": "XGB", "GRU": "GRU",
                "TCN": "TCN", "FCA-BiLSTM-HSK": "FCA"}
    t4 = []
    for mdl, key in name_map.items():
        d = msum[msum.model == mdl]
        t4.append({"model": mdl,
                   "accuracy": round(d.accuracy.mean() * 100, 1),
                   "sd": round(d.accuracy.std(ddof=1) * 100, 1),
                   "precision_H": round(d.precision_H.mean() * 100, 1),
                   "recall_H": round(d.recall_H.mean() * 100, 1),
                   "f1_H": round(d.f1_H.mean() * 100, 1),
                   "macro_auc": round(d.macro_auc.mean(), 3)})
        nums[f"ACC_{key}"] = round(d.accuracy.mean() * 100, 1)
        nums[f"T4_{key}_ACC"] = f"{d.accuracy.mean()*100:.1f}±{d.accuracy.std(ddof=1)*100:.1f}"
        nums[f"T4_{key}_HP"] = f"{d.precision_H.mean()*100:.1f}±{d.precision_H.std(ddof=1)*100:.1f}"
        nums[f"T4_{key}_HR"] = f"{d.recall_H.mean()*100:.1f}±{d.recall_H.std(ddof=1)*100:.1f}"
        nums[f"T4_{key}_HF1"] = f"{d.f1_H.mean()*100:.1f}±{d.f1_H.std(ddof=1)*100:.1f}"
        nums[f"T4_{key}_AUC"] = f"{d.macro_auc.mean():.3f}±{d.macro_auc.std(ddof=1):.3f}"
    pd.DataFrame(t4).to_csv(TAB / "table4_comparison.csv", index=False, encoding="utf-8-sig")
    nums["GAP_SVM"] = round(nums["ACC"] - nums["ACC_SVM"], 1)
    nums["GAP_LSTM"] = round(nums["ACC"] - nums["ACC_LSTM"], 1)
    # Use UNSHROUNDED per-seed means; 92.6497-90.0907=2.5590 -> 2.6 pp.
    others_unrounded=[msum[msum.model==m].accuracy.mean()*100
                      for m in ('XGBoost','GRU','TCN')]
    nums["GAIN_MIN"] = round(fca.accuracy.mean()*100 - max(others_unrounded), 1)
    nums["GAIN_MAX"] = round(fca.accuracy.mean()*100 - min(others_unrounded), 1)

    # ---------------- ablation ----------------
    ab = {"BiLSTM_SVM": ("Bi-LSTM-SVM (baseline)", "BASE"),
          "FC_BiLSTM_HSK": ("w/o temporal attention", "NOATT"),
          "BiLSTM_HSK": ("w/o fuzzy-cloud features", "NOFCA"),
          "FCA_BiLSTM": ("w/o KNN cascade correction", "NOKNN"),
          "FCA-BiLSTM-HSK": ("full model", "FULL")}
    rows5 = []
    for mdl, (lab, key) in ab.items():
        d = msum[msum.model == mdl]
        v_ = d.accuracy.mean() * 100
        s_ = d.accuracy.std(ddof=1) * 100
        rows5.append({"variant": lab, "accuracy": f"{v_:.1f}±{s_:.1f}"})
        nums[f"T5_{key}"] = f"{v_:.1f}±{s_:.1f}"
        nums[f"ACC_{key}"] = round(v_, 1)
        nums[f"SD_{key}"] = round(s_, 1)
    pd.DataFrame(rows5).to_csv(TAB / "table5_ablation.csv", index=False, encoding="utf-8-sig")
    for key in ("NOFCA", "NOATT", "NOKNN"):
        nums[f"DROP_{key}"] = round(nums["ACC"] - nums[f"ACC_{key}"], 1)

    # net contribution of the KNN stage under the median seed
    base_m = msum[(msum.model == "FCA_BiLSTM") & (msum.seed == med_seed)].iloc[0]
    nums["KNN_NET"] = round((mid.accuracy - base_m.accuracy) * 100, 1)
    nums["KNN_NET_MEAN"] = round(
        (fca.accuracy.mean() - msum[msum.model == "FCA_BiLSTM"].accuracy.mean()) * 100, 1)

    # ---------------- theta sweep and low-confidence subset ----------------
    # Recompute the theta sweep window-by-window (median seed) from the margin
    # distribution and knn_subset. Convention: windows with margin < theta are
    # routed to the KNN; the shipped per-window KNN verdicts cover the
    # theta* = 0.35 routing subset; newly routed windows beyond theta* keep
    # their SVM verdict under a conservative convention (accuracy is a lower
    # bound).
    svm_map = dict(zip(zip(knn.firm_id, knn.win_index), knn.svm_pred))
    fin_map = dict(zip(zip(knn.firm_id, knn.win_index), knn.final_pred))
    PUB_GRID = [0.10, 0.20, 0.30, 0.35, 0.40, 0.50, 0.60]
    y_t = m.y_true.to_numpy()
    rows_theta = []
    for th in PUB_GRID:
        yp_th = np.asarray([
            (fin_map.get((f, w), svm_map.get((f, w), yp0)) if mg < th
             else svm_map.get((f, w), yp0))
            for f, w, mg, yp0 in zip(m.firm_id, m.win_index, m.margin, m.y_pred)])
        rows_theta.append({"theta": th,
                           "n_low_confidence": int((m.margin < th).sum()),
                           "accuracy_pct": round(float((yp_th == y_t).mean() * 100), 1)})
    theta = pd.DataFrame(rows_theta)
    theta.to_csv(TAB / "tableA3_theta.csv", index=False, encoding="utf-8-sig")
    # reconcile with the shipped predictions/theta_sensitivity.csv
    ref_p = RES / "theta_sensitivity.csv"
    if ref_p.exists():
        ref = pd.read_csv(ref_p)
        chk = theta.merge(ref, on="theta", suffixes=("_re", "_tr"))
        assert (chk.n_low_confidence_re == chk.n_low_confidence_tr).all(), \
            "theta_sensitivity.csv disagrees with the recomputation"
        assert (chk.accuracy_pct_re == chk.accuracy_pct_tr).all(), \
            "theta_sensitivity.csv disagrees with the recomputation"
    nums["THETA_STAR"] = float(theta.loc[theta.accuracy_pct.idxmax(), "theta"])
    hi = theta[theta.accuracy_pct == theta.accuracy_pct.max()]
    nums["THETA_NOTE"] = (f"both occur within theta = {hi.theta.min():.2f}-"
                          f"{hi.theta.max():.2f}")
    nums["ACC_THETA_MIN"] = float(theta.accuracy_pct.min())
    nums["ACC_THETA_MAX"] = float(theta.accuracy_pct.max())

    n_low = len(knn)
    svm_ok = int((knn.svm_pred == knn.y_true).sum())
    fin_ok = int((knn.final_pred == knn.y_true).sum())
    fix = int(knn.knn_corrected.sum())
    harm = int(knn.knn_broken.sum())
    nums.update({"LOW_N": n_low, "LOW_SHARE": pct(n_low / nums["N_TEST"]),
                 "LOW_A": svm_ok, "LOW_B": fin_ok,
                 "LOW_SVM": pct(svm_ok / n_low), "LOW_KNN": pct(fin_ok / n_low),
                 "LOW_FIX": fix, "LOW_HARM": harm, "LOW_NET": fix - harm})
    nums["KNN_GAIN"] = round((fin_ok - svm_ok) / nums["N_TEST"] * 100, 1)
    # actual convention: replace subset predictions with the SVM verdict only
    yp_svm = yp.copy()
    pos = {k2: i for i, k2 in enumerate(zip(m.firm_id, m.win_index))}
    for f, wi, sp in zip(knn.firm_id, knn.win_index, knn.svm_pred):
        if (f, wi) in pos:
            yp_svm[pos[(f, wi)]] = NUM[sp]
    nums["ACC_NO_KNN_OVERALL"] = pct((yp_svm == yt).mean())
    nums["KNN_GAIN"] = round(nums["ACC"] - nums["ACC_NO_KNN_OVERALL"], 1)

    # ---------------- Table A2: all 30 runs, not only the six seed-3 rows ----------------
    # Independent script computes this from each original per-seed CSV and
    # writes its SHA256 so the result is fully traceable to supplied log bytes.
    from subprocess import run as _run
    import sys as _sys
    _run([_sys.executable, str(ROOT/'02_code/reconcile_review.py')],
         cwd=ROOT,check=True,capture_output=True,text=True)
    best=pd.read_csv(TAB/'tableA2_best_epoch.csv')
    assert len(best)==30
    s3=best[best.seed==med_seed].sort_values('model')
    nums['EPOCH_NOTE']='、'.join(f'{r.model} {int(r.best_epoch)}' for r in s3.itertuples())

    # ---------------- Table A1 annual distribution of high-risk events ----------------
    hv = v[v.risk_label == "H"].copy()
    ev2 = ev.set_index(["firm_id", "quarter"])
    cols = ["st_flag", "audit_qualified", "commercial_paper_overdue", "interest_overdue"]
    rec = []
    for r in hv.itertuples():
        key = (r.firm_id, r.win_end_quarter)
        if key in ev2.index:
            row = ev2.loc[key]
            if isinstance(row, pd.DataFrame):
                row = row.iloc[0]
            rec.append([r.win_end_quarter[:4]] + [int(row[c]) for c in cols])
        else:
            rec.append([r.win_end_quarter[:4]] + [0] * 4)
    evdf = pd.DataFrame(rec, columns=["year"] + cols)
    a5 = evdf.groupby("year")[cols].sum()
    a5["Total"] = a5.sum(axis=1)
    a5.to_csv(TAB / "tableA1_events_by_year.csv", encoding="utf-8-sig")
    nums["A5_YEARS"] = [str(x) for x in a5.index]
    nums["A5_PRE2021_H"] = int(a5.loc[[y for y in a5.index if int(y) < 2021], "Total"].sum())
    nums["A5_POST2021_H"] = int(a5.loc[[y for y in a5.index if int(y) >= 2021], "Total"].sum())
    nums["A5_CPO_POST"] = int(a5.loc[[y for y in a5.index if int(y) >= 2021],
                                    "commercial_paper_overdue"].sum())
    nums["A5_CPO_ALL"] = int(a5["commercial_paper_overdue"].sum())
    a5.to_csv(TAB / "tableA1_events_by_year.csv", encoding="utf-8-sig")

    # ---------------- write outputs ----------------
    (ROOT / "04_outputs" / "numbers.json").write_text(
        json.dumps(nums, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({k: nums[k] for k in sorted(nums)}, ensure_ascii=False, indent=1)[:4000])
    print("\ntables ->", [p.name for p in sorted(TAB.glob('*.csv'))])


if __name__ == "__main__":
    main()
