# -*- coding: utf-8 -*-
"""Compile measurements from NEW training only; never splice old snapshots.

The archived Table 4 and Table 5 are not overwritten. Five-seed tables
require five actual runs for every listed model; a partial smoke run cannot
be presented as a publication-ready experiment.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import config as C

MAIN=['svm','lstm','xgboost','gru','tcn','fca_bilstm']
ABL=['basic_bilstm_svm','no_fuzzy_cloud','no_temporal_attention','no_knn','fca_bilstm']
LABEL={'svm':'SVM','lstm':'LSTM','xgboost':'XGBoost','gru':'GRU','tcn':'TCN',
       'fca_bilstm':'FCA-BiLSTM-HSK',
       'basic_bilstm_svm':'Bi-LSTM-SVM (baseline)',
       'no_fuzzy_cloud':'w/o fuzzy-cloud features',
       'no_temporal_attention':'w/o temporal attention',
       'no_knn':'w/o KNN cascade correction'}


def ensure_complete(df, names, file):
    for name in names:
        seeds=sorted(df.loc[df.model==name,'seed'].tolist())
        if seeds!=C.SEEDS:
            raise RuntimeError(f'{file}: {name}: complete five-seed run required; have {seeds}')


def aggregate(df, names):
    result=[]
    for name in names:
        d=df[df.model==name].sort_values('seed')
        r={'model':LABEL[name],'code':name,'n_seeds':len(d)}
        for col in ['accuracy','high_precision','high_recall','high_f1','macro_auc','ap_high']:
            r[col+'_mean']=float(d[col].mean())
            r[col+'_sample_sd']=float(d[col].std(ddof=1))
        result.append(r)
    return pd.DataFrame(result)


def main(mode):
    p=C.OUT/'retrained'/mode
    out=p/'tables'
    out.mkdir(parents=True,exist_ok=True)
    main_file=p/'main'/'metrics.csv'
    abl_file=p/'ablation'/'metrics.csv'
    have_main=main_file.exists()
    have_ablation=abl_file.exists()
    if not have_main and not have_ablation:
        raise RuntimeError('No new metrics exist; training did not run')
    if have_main:
        m=pd.read_csv(main_file)
        ensure_complete(m,MAIN,main_file)
        aggregate(m,MAIN).to_csv(out/'table4.csv',index=False,encoding='utf-8-sig')
        pred=pd.read_csv(p/'main'/'predictions.csv',dtype={'Stkcd':str})
        wide=[]
        for seed in C.SEEDS:
            a=pred.query('model=="fca_bilstm" and seed==@seed')
            b=pred.query('model=="tcn" and seed==@seed')
            joined=a.merge(b,on=['Stkcd','win_index'],suffixes=('_main','_tcn'),validate='one_to_one')
            if len(joined)!=len(a) or len(a)!=len(b):
                raise ValueError('Per-window paired predictions incomplete')
            if not (joined.y_true_main==joined.y_true_tcn).all():
                raise ValueError('True labels differ between paired models')
            correcta=joined.y_pred_main==joined.y_true_main
            correctb=joined.y_pred_tcn==joined.y_true_main
            high=joined.y_true_main==3
            wide.append({'seed':seed,'N':len(joined), 'high_N':int(high.sum()),
                'high_TP':int((high&correcta).sum()),
                'high_recall':float(correcta[high].mean()),
                'main_correct':int(correcta.sum()),'tcn_correct':int(correctb.sum()),
                'b':int((correcta&~correctb).sum()),
                'c':int((~correcta&correctb).sum()),
                'both_correct':int((correcta&correctb).sum()),
                'both_wrong':int((~correcta&~correctb).sum())})
        table=pd.DataFrame(wide)
        table.to_csv(out/'table6.csv',index=False,encoding='utf-8-sig')
        # Fix the median seed from NEW complete five-run accuracies, never use 3 blindly.
        bymain=m[m.model=='fca_bilstm'].sort_values('accuracy')
        median=int(bymain.iloc[2].seed)
        pm=pred.query('seed==@median and model=="fca_bilstm"').copy()
        pt=pred.query('seed==@median and model=="tcn"').copy()
        j=pm.merge(pt,on=['Stkcd','win_index'],suffixes=('_main','_tcn'),validate='one_to_one')
        j.to_csv(out/'median_seed_paired_predictions.csv',index=False,encoding='utf-8-sig')
        (out/'median_seed.txt').write_text(str(median)+'\n',encoding='utf-8')
    if have_ablation:
        a=pd.read_csv(abl_file)
        ensure_complete(a,ABL,abl_file)
        aggregate(a,ABL).to_csv(out/'table5.csv',index=False,encoding='utf-8-sig')
    print('Recomputed only from new complete five-seed runs:',out)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--data-mode',choices=['verified','legacy'],default='verified')
    a=ap.parse_args()
    main(a.data_mode)
