# -*- coding: utf-8 -*-
"""Independent recomputation of the theta sweep (training environment not required).

Reads `margin` (Delta g(V), the SVM preliminary confidence gap), `y_true`
and `y_pred` from 04_outputs/predictions/predictions_all.csv, plus `svm_pred`
(SVM preliminary verdict) and `final_pred` (KNN cascade verdict) of the
theta* routing subset in 04_outputs/predictions/knn_subset.csv, and
recomputes test accuracy and the low-confidence count for each theta.

Sweep convention (consistent with Section 4.3):
  * windows with margin < theta are routed to the KNN; the rest keep the SVM
    preliminary verdict;
  * the shipped per-window KNN verdicts cover the theta* = 0.35 routing
    subset (142 windows). Newly routed windows beyond theta* keep their SVM
    verdict under a conservative convention, so accuracy on the theta >=
    theta* segment is a lower bound; the theta <= theta* segment is
    recomputed window-exactly;
  * default seed = 3 (median seed), consistent with Table A3.

Outputs:
  04_outputs/tables/theta_check.csv           full grid (0.10-0.60, step 0.05)
  04_outputs/tables/tableA3_theta.csv         the 7 published grid points of Table A3
  04_outputs/tables/theta_reconciliation.csv  reconciliation vs predictions/theta_sensitivity.csv

Usage: python calibrate_theta.py [--predictions PATH] [--seed 3]
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

import config as C

PUB_GRID = [0.10, 0.20, 0.30, 0.35, 0.40, 0.50, 0.60]


def sweep(df: pd.DataFrame, knn_sub: pd.DataFrame, thetas) -> pd.DataFrame:
    svm_map = dict(zip(zip(knn_sub.firm_id, knn_sub.win_index), knn_sub.svm_pred))
    fin_map = dict(zip(zip(knn_sub.firm_id, knn_sub.win_index), knn_sub.final_pred))
    y = df.y_true.to_numpy()
    rows = []
    for th in thetas:
        yp = []
        for f, w, mg, yp0 in zip(df.firm_id, df.win_index, df.margin, df.y_pred):
            key = (f, w)
            if mg < th:
                yp.append(fin_map.get(key, svm_map.get(key, yp0)))
            else:
                yp.append(svm_map.get(key, yp0))
        yp = np.asarray(yp)
        rows.append({"seed": int(df.seed.iloc[0]), "theta": float(th),
                     "accuracy": float((yp == y).mean()),
                     "low_conf_n": int((df.margin < th).sum()),
                     "n": int(len(y))})
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", default=str(C.OUT_PRED / "predictions_all.csv"))
    ap.add_argument("--seed", type=int, default=3, help="median seed (consistent with Table A3)")
    args = ap.parse_args()
    df = pd.read_csv(args.predictions)
    df = df[(df.model == "FCA-BiLSTM-HSK") & (df.seed == args.seed)]
    if df.empty:
        raise SystemExit(f"prediction file contains no FCA-BiLSTM-HSK seed={args.seed} records.")
    knn_sub = pd.read_csv(C.OUT_PRED / "knn_subset.csv")

    # full-grid sweep
    out = sweep(df, knn_sub, C.THETA_GRID)
    out.to_csv(C.OUT_TABLES / "theta_check.csv", index=False, encoding="utf-8-sig")

    # the 7 published grid points of Table A3
    pub = out[out.theta.isin(PUB_GRID)][["theta", "low_conf_n", "accuracy"]].copy()
    pub.columns = ["theta", "n_low_confidence", "accuracy_pct"]
    pub["accuracy_pct"] = (pub["accuracy_pct"] * 100).round(1)
    pub.to_csv(C.OUT_TABLES / "tableA3_theta.csv", index=False, encoding="utf-8-sig")

    # reconcile with the training-stage theta_sensitivity.csv
    ref_path = C.OUT_PRED / "theta_sensitivity.csv"
    if ref_path.exists():
        ref = pd.read_csv(ref_path)
        chk = pub.merge(ref, on="theta", suffixes=("_check", "_train"))
        chk["diff_acc"] = (chk.accuracy_pct_check - chk.accuracy_pct_train).abs()
        chk["diff_n"] = (chk.n_low_confidence_check - chk.n_low_confidence_train).abs()
        chk.to_csv(C.OUT_TABLES / "theta_reconciliation.csv", index=False,
                   encoding="utf-8-sig")
        bad = chk[(chk.diff_acc > 1e-9) | (chk.diff_n > 0)]
        print(f"reconciliation finished: {len(chk)} rows, {len(bad)} mismatches")
        if len(bad):
            print(bad.head(20).to_string())
    print(pub.to_string(index=False))


if __name__ == "__main__":
    main()
