# -*- coding: utf-8 -*-
"""Evaluation metrics and statistical tests.

Covers the four statistical protocols:
  * firm-clustered bootstrap confidence intervals (P1-3)
  * McNemar test with continuity correction (P2)
  * random-guess expectation of adjacent misclassifications and weighted kappa (P1-4)
  * permutation test for attention-event alignment (P1-11)
"""
from __future__ import annotations

import numpy as np
from scipy import stats
from sklearn.metrics import (accuracy_score, cohen_kappa_score,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)

from config import BOOT_SEED, N_BOOT, N_PERM


# ---------------------------------------------------------------- base metrics
def class_report(y_true, y_pred, labels=(1, 2, 3)) -> dict:
    out = {"accuracy": accuracy_score(y_true, y_pred)}
    for name, avg in (("macro_f1", "macro"), ("weighted_f1", "weighted")):
        out[name] = f1_score(y_true, y_pred, average=avg, labels=list(labels),
                             zero_division=0)
    # high-risk class (label = 3): one-vs-rest per-class metrics with macro averaging
    out["high_precision"] = precision_score(y_true, y_pred, labels=[3],
                                            average="macro", zero_division=0)
    out["high_recall"] = recall_score(y_true, y_pred, labels=[3],
                                      average="macro", zero_division=0)
    out["high_f1"] = f1_score(y_true, y_pred, labels=[3],
                              average="macro", zero_division=0)
    return out


def macro_auc(y_true, proba, labels=(1, 2, 3)) -> float:
    """Macro AUC (one-vs-rest, class-equal weighted). The proba column order must match labels."""
    aucs = []
    for i, lab in enumerate(labels):
        y_bin = (np.asarray(y_true) == lab).astype(int)
        if y_bin.min() == y_bin.max():
            continue
        aucs.append(roc_auc_score(y_bin, proba[:, i]))
    return float(np.mean(aucs)) if aucs else np.nan


def average_precision_high(y_true, proba, labels=(1, 2, 3)) -> float:
    from sklearn.metrics import average_precision_score
    idx = list(labels).index(3)
    return float(average_precision_score((np.asarray(y_true) == 3).astype(int),
                                         proba[:, idx]))


# ---------------------------------------------------------------- clustered uncertainty
def cluster_bootstrap(y_true, y_pred, groups, metric_fn, n_boot=N_BOOT,
                      seed=BOOT_SEED, alpha=0.05):
    """Bootstrap confidence interval resampling whole firms (groups).

    Firms rather than windows are the resampling units, so within-firm window correlation does not overstate interval precision.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    groups = np.asarray(groups)
    uniq = np.unique(groups)
    index_by_group = {g: np.where(groups == g)[0] for g in uniq}
    rng = np.random.default_rng(seed)
    stats_ = []
    for _ in range(n_boot):
        pick = rng.choice(uniq, size=uniq.size, replace=True)
        idx = np.concatenate([index_by_group[g] for g in pick])
        if np.unique(y_true[idx]).size < 2:
            continue
        try:
            stats_.append(metric_fn(y_true[idx], y_pred[idx]))
        except Exception:
            continue
    stats_ = np.asarray(stats_, dtype=float)
    lo, hi = np.nanpercentile(stats_, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(np.nanmean(stats_)), float(lo), float(hi), n_boot


def wilson_ci(k: int, n: int, alpha: float = 0.05):
    """Wilson interval for a binomial proportion (per-window; reference only)."""
    if n == 0:
        return (np.nan, np.nan)
    z = stats.norm.ppf(1 - alpha / 2)
    p = k / n
    denom = 1 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denom
    return (centre - half, centre + half)


# ---------------------------------------------------------------- paired tests
def mcnemar(y_true, pred_a, pred_b, continuity: bool = True) -> dict:
    """McNemar test. b = a correct & b wrong, c = a wrong & b correct; continuity correction applied by default."""
    y_true = np.asarray(y_true)
    ok_a = np.asarray(pred_a) == y_true
    ok_b = np.asarray(pred_b) == y_true
    b = int(np.sum(ok_a & ~ok_b))
    c = int(np.sum(~ok_a & ok_b))
    if continuity:
        chi2 = (abs(b - c) - 1) ** 2 / (b + c) if (b + c) > 0 else np.nan
    else:
        chi2 = (b - c) ** 2 / (b + c) if (b + c) > 0 else np.nan
    p = 1 - stats.chi2.cdf(chi2, df=1) if not np.isnan(chi2) else np.nan
    return {"b": b, "c": c, "chi2": float(chi2),
            "p_value": float(p), "continuity_corrected": continuity}


# ---------------------------------------------------------------- ordinal structure
def adjacent_error_random_baseline(y_true, prior=None, labels=(1, 2, 3)):
    """Expected share of adjacent misclassifications among all misclassifications
    under random guessing with imbalanced priors.

    Derivation: guessing class c and being wrong, the probability that
    |c - y| = 1 is
        P(adjacent | wrong) = sum_y p(y) * [p(y-1) + p(y+1)] / (1 - sum_y p(y)^2)
    """
    y_true = np.asarray(y_true)
    labels = list(labels)
    if prior is None:
        counts = np.array([(y_true == c).sum() for c in labels], dtype=float)
        prior = counts / counts.sum()
    prior = np.asarray(prior, dtype=float)
    num, den = 0.0, 0.0
    for k, c in enumerate(labels):
        others = prior.copy()
        others[k] = 0.0
        den += prior[k] * others.sum()
        for j, c2 in enumerate(labels):
            if abs(c2 - c) == 1:
                num += prior[k] * prior[j]
    return float(num / den) if den > 0 else np.nan


def adjacent_error_share(y_true, y_pred, labels=(1, 2, 3)):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    wrong = y_true != y_pred
    if wrong.sum() == 0:
        return np.nan, 0
    adj = np.abs(y_true[wrong] - y_pred[wrong]) == 1
    return float(adj.mean()), int(wrong.sum())


def weighted_kappa(y_true, y_pred, labels=(1, 2, 3), weights="quadratic"):
    return float(cohen_kappa_score(y_true, y_pred, labels=list(labels),
                                   weights=weights))


def bootstrap_adjacent_vs_random(y_true, y_pred, n_boot=N_BOOT, seed=BOOT_SEED):
    """Bootstrap difference interval of the adjacent-misclassification share vs the random baseline."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    rng = np.random.default_rng(seed)
    diffs = []
    n = y_true.size
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        share, n_wrong = adjacent_error_share(y_true[idx], y_pred[idx])
        if n_wrong == 0:
            continue
        base = adjacent_error_random_baseline(y_true[idx])
        diffs.append(share - base)
    diffs = np.asarray(diffs)
    return float(np.mean(diffs)), float(np.percentile(diffs, 2.5)), \
        float(np.percentile(diffs, 97.5)), float(np.mean(diffs > 0))


# ---------------------------------------------------------------- attention alignment
def attention_alignment_permutation(attn, event_idx, tol=1, n_perm=N_PERM,
                                    seed=BOOT_SEED):
    """Hit rate of the top-2 attention falling within +/- tol quarters of the event quarter, with a permutation-test p-value.

    Null hypothesis: attention weights are unrelated to event position. Permutation shuffles attention weights within each window.
    """
    attn = np.asarray(attn, dtype=float)
    event_idx = np.asarray(event_idx)
    mask = event_idx >= 0
    if mask.sum() == 0:
        return {"hit_rate": np.nan, "p_value": np.nan, "n": 0}
    a, e = attn[mask], event_idx[mask]

    def hit_rate(A):
        top2 = np.argsort(-A, axis=1)[:, :2]
        return float(np.mean(np.any(np.abs(top2 - e[:, None]) <= tol, axis=1)))

    obs = hit_rate(a)
    rng = np.random.default_rng(seed)
    null = np.empty(n_perm)
    for i in range(n_perm):
        perm = np.argsort(rng.random(a.shape), axis=1)
        null[i] = hit_rate(np.take_along_axis(a, perm, axis=1))
    p = (1 + np.sum(null >= obs)) / (n_perm + 1)
    return {"hit_rate": obs, "p_value": float(p), "n": int(mask.sum()),
            "null_mean": float(null.mean())}


def confusion(y_true, y_pred, labels=(1, 2, 3)) -> np.ndarray:
    return confusion_matrix(y_true, y_pred, labels=list(labels))
