# -*- coding: utf-8 -*-
"""Reproducibility audit of the SHIPPED historical prediction snapshot.

No statistical values are imputed; all reported counts come from predictions_all
and all best epochs come from the 30 log files. Historical event provenance is
NOT verified by this script and is reported separately.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PRED=ROOT/'04_outputs/predictions'
TABLES=ROOT/'04_outputs/tables'
LOGS=ROOT/'04_outputs/logs'
DOCS=ROOT/'05_docs'
LAB={'L':1,'M':2,'H':3}


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as fh:
        for part in iter(lambda:fh.read(1024*1024),b''):h.update(part)
    return h.hexdigest()


def main():
    preds=pd.read_csv(PRED/'predictions_all.csv',dtype={'firm_id':str})
    summary=pd.read_csv(PRED/'metrics_summary.csv')
    ws=pd.read_csv(PRED/'window_split.csv',dtype={'firm_id':str})
    unique_valid=ws[ws.status=='valid'][['firm_id','win_index','risk_label']].copy()
    assert unique_valid[['firm_id','win_index']].duplicated().sum()==0
    checks=[]
    for (mod,seed),g in preds.groupby(['model','seed'],sort=False):
        assert len(g)==1102 and len(g[['firm_id','win_index']].drop_duplicates())==1102,(mod,seed)
        check=g[['firm_id','win_index','y_true']].merge(unique_valid,on=['firm_id','win_index'],validate='one_to_one')
        assert len(check)==1102 and (check.y_true==check.risk_label).all(),(mod,seed)
        ref=summary[(summary.model==mod)&(summary.seed==seed)]
        assert len(ref)==1,(mod,seed,'summary missing')
        ref=ref.iloc[0]
        acc=(g.y_true==g.y_pred).mean()
        assert abs(acc-ref.accuracy)<1e-12,(mod,seed,'accuracy mismatch')
        for k in 'LMH':
            n=(g.y_true==k).sum();pp=(g.y_pred==k).sum()
            tp=((g.y_pred==k)&(g.y_true==k)).sum()
            recall=tp/n
            prec=tp/pp if pp else 0
            assert abs(recall-ref['recall_'+k])<1e-12,(mod,seed,k,'recall')
            assert abs(prec-ref['precision_'+k])<1e-12,(mod,seed,k,'precision')
        assert np.allclose(g[['p_low','p_medium','p_high']].sum(axis=1).values,1,atol=1e-6)
        checks.append({'model':mod,'seed':seed,'correct':int((g.y_true==g.y_pred).sum()),
                       'accuracy':acc,'high_tp':int(((g.y_true=='H')&(g.y_pred=='H')).sum()),
                       'high_n':int((g.y_true=='H').sum()),'high_recall':ref.recall_H})
    assert len(checks)==49
    full=preds[preds.model=='FCA-BiLSTM-HSK'].copy()
    full_acc=pd.DataFrame(checks).query('model == "FCA-BiLSTM-HSK"').sort_values('accuracy')
    median_seed=int(full_acc.iloc[2].seed)
    assert median_seed==3
    records=[]
    for seed in range(1,6):
        a=preds[(preds.model=='FCA-BiLSTM-HSK')&(preds.seed==seed)]
        b=preds[(preds.model=='TCN')&(preds.seed==seed)]
        joined=a[['firm_id','industry','win_index','win_end_quarter','y_true','y_pred']].merge(
            b[['firm_id','win_index','y_true','y_pred']],on=['firm_id','win_index'],
            suffixes=('_FCA','_TCN'),validate='one_to_one')
        assert len(joined)==1102 and (joined.y_true_FCA==joined.y_true_TCN).all()
        ok_a=joined.y_true_FCA==joined.y_pred_FCA
        ok_b=joined.y_true_FCA==joined.y_pred_TCN
        bb=int((ok_a&~ok_b).sum());cc=int((~ok_a&ok_b).sum())
        na=int(ok_a.sum()); nb=int(ok_b.sum())
        highn=int((joined.y_true_FCA=='H').sum())
        htp=int(((joined.y_true_FCA=='H')&(joined.y_pred_FCA=='H')).sum())
        records.append(dict(seed=seed,n=1102,high_n=highn,correct_FCA=na,
                            accuracy_FCA_pct=na/1102*100,high_tp=htp,
                            high_recall_pct=htp/highn*100,correct_TCN=nb,
                            accuracy_TCN_pct=nb/1102*100,paired_difference_pp=(na-nb)/1102*100,
                            b=bb,c=cc,both_correct=int((ok_a&ok_b).sum()),
                            both_wrong=int((~ok_a&~ok_b).sum())))
        if seed==median_seed:
            joined['FCA_correct']=ok_a.astype(int)
            joined['TCN_correct']=ok_b.astype(int)
            joined['paired_group']=np.select([ok_a&ok_b,ok_a&~ok_b,~ok_a&ok_b],
                ['both_correct','FCA_only_correct','TCN_only_correct'],default='both_wrong')
            joined.to_csv(PRED/'paired_window_seed3_1102.csv',index=False,encoding='utf-8-sig')
    df=pd.DataFrame(records).sort_values('seed')
    assert list(df.high_tp)==[91,90,90,90,91]
    assert (df.b[df.seed==3].iloc[0],df.c[df.seed==3].iloc[0])==(59,19)
    df.to_csv(TABLES/'table6_seed_reconciliation.csv',index=False,float_format='%.10f',encoding='utf-8-sig')
    pairs=df[['seed','n','correct_FCA','correct_TCN','b','c','both_correct','both_wrong','paired_difference_pp']]
    pairs.to_csv(TABLES/'paired_counts_by_seed.csv',index=False,float_format='%.10f',encoding='utf-8-sig')

    row_stat=[]
    for mod in ['FCA-BiLSTM-HSK','TCN']:
        tmp=pd.DataFrame(checks).query('model == @mod')
        for name,field in [('accuracy_pct','accuracy'),('high_recall_pct','high_recall')]:
            x=tmp[field].to_numpy()*100
            row_stat.append({'model':mod,'metric':name,'n_seeds':len(x),'mean_pct':x.mean(),
                'sample_sd_pp':x.std(ddof=1),'minimum_pct':x.min(),'maximum_pct':x.max(),
                'range_pp':x.max()-x.min(), 'source':'per-window integer counts, unrounded'})
    pd.DataFrame(row_stat).to_csv(TABLES/'statistics_unrounded.csv',index=False,
                                  float_format='%.12f',encoding='utf-8-sig')

    log_rows=[]; comb=[]; nfiles=0
    for name in ['bilstm','fc_bilstm','fca_bilstm','lstm','gru','tcn']:
        for seed in range(1,6):
            f=LOGS/f'training_log_{name}_seed{seed}.csv'
            assert f.is_file(),f
            l=pd.read_csv(f)
            assert len(l)==200 and list(l.epoch)==list(range(1,201)) and not l.early_stopped.astype(str).str.lower().eq('true').any(),str(f)
            assert l.seed.nunique()==1 and int(l.seed.iloc[0])==seed
            assert l.config.nunique()==1 and l.config.iloc[0]==name
            best=l.loc[l.val_loss.idxmin()]
            log_rows.append({'model':name,'seed':seed,'best_epoch':int(best.epoch),
                             'best_val_loss':float(best.val_loss),'train_loss_at_best':float(best.train_loss),
                             'final_epoch':200,'early_stopped':False,'csv_sha256':sha(f),
                             'file':str(f.relative_to(ROOT))})
            l['source_log']=f.name
            comb.append(l)
            nfiles+=1
    logs=pd.DataFrame(log_rows)
    assert nfiles==30 and len(comb)==30 and logs.best_epoch.between(190,199).all()
    logs.to_csv(TABLES/'tableA2_best_epoch.csv',index=False,encoding='utf-8-sig')
    logs.to_csv(DOCS/'training_logs_sha256_index.csv',index=False,encoding='utf-8-sig')
    pd.concat(comb,ignore_index=True).to_csv(LOGS/'training_log_all_30.csv',index=False,encoding='utf-8-sig')

    xgb=preds[preds.model=='XGBoost']
    assert set(xgb.seed)=={1,2,3,4} and xgb.groupby('seed').size().eq(1102).all()
    diff=pd.read_csv(ROOT/'04_outputs/diagnostics/xgboost_seed45_diff.csv')
    assert len(diff)==220
    assert diff[['firm_id','win_index']].duplicated().sum()==0
    assert (diff.y_pred_s4!=diff.y_pred_s5).all()
    xg4=xgb[xgb.seed==4][['firm_id','win_index','y_true','y_pred']]
    xchk=diff.merge(xg4,on=['firm_id','win_index'],validate='one_to_one')
    assert len(xchk)==220 and (xchk.y_true_x==xchk.y_true_y).all() and (xchk.y_pred==xchk.y_pred_s4).all()
    assert (df.high_n==96).all()
    result={
        'status':'SNAPSHOT_STATISTICS_PASS__OFFICIAL_EVENT_PROVENANCE_PENDING',
        'number_model_seed_records':len(checks),
        'test_windows_per_seed':1102,
        'median_seed':median_seed,
        'high_recall_mean_pct':float(df.high_recall_pct.mean()),
        'high_recall_sample_sd_pp':float(df.high_recall_pct.std(ddof=1)),
        'high_recall_extremes_pct':[float(df.high_recall_pct.min()),float(df.high_recall_pct.max())],
        'pair_seed3':{'b':59,'c':19,'correct_FCA':1020,'correct_TCN':980},
        'n_epoch_logs':nfiles,'n_epoch_records':sum(map(len,comb)),
        'all_best_epochs_190_through_199':True,
        'xgboost_seed5_full_predictions_available':False,
        'xgboost_seed5_disagreement_rows_in_diagnostic':len(diff),
        'official_commercial_paper_rows_verified':0,
        'official_ST_rows_verified':0,
        'notes':'Statistical consistency is NOT independent verification of the underlying risk labels, training runs, or official exchange records.'
    }
    (DOCS/'statistical_reconciliation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':main()
