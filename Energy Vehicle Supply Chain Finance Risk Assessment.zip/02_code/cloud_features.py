# -*- coding: utf-8 -*-
"""Fuzzy-cloud feature mapping: backward normal cloud generator based on
sample moments.

For the indicator observation sequence x = {x_1,...,x_N} within each window,
three numerical characteristics are computed:

    Ex = mean(x)                                   (1)(2)
    En = sqrt(pi/2) * mean(|x - Ex|)               (4)
    He = sqrt(max(S^2 - En^2, 0)),  where S^2 is the sample variance  (5)

Equation (5) takes the non-negative part to avoid sqrt of negative values when S^2 < En^2. With a small sample, He is easily truncated to 0; the module therefore also reports the frequency and quantiles of He == 0 for the small-sample discussion (appendix Table A3).

Window-size note: this module itself is window-size agnostic (it transforms
whatever observation sequence it is given). The authoritative estimation
protocol is in ``train.py::rolling_cloud(X, L=4)``: at EVERY time step t of a
window, the cloud characteristics (Ex, En, He) are estimated from the most
recent L = 4 quarters of observations up to t (all available observations when
fewer than L), i.e. a rolling 4-quarter window — NOT the full 8-quarter
window. This matches the manuscript Table 3 and Section 3.4.
"""
from __future__ import annotations

import numpy as np

SQRT_HALF_PI = np.sqrt(np.pi / 2.0)


def reverse_cloud(x: np.ndarray) -> tuple[float, float, float]:
    """Backward cloud transform of one window; returns (Ex, En, He)."""
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    n = x.size
    if n < 2:
        return (np.nan, np.nan, np.nan)
    ex = x.mean()
    s2 = x.var(ddof=1)
    en = SQRT_HALF_PI * np.mean(np.abs(x - ex))
    he = np.sqrt(max(s2 - en ** 2, 0.0))
    return float(ex), float(en), float(he)


def cloud_panel(values: np.ndarray) -> np.ndarray:
    """Compute cloud features for a (n_windows, n_indicators, T) array.

    Returns
    -------
    ndarray, shape (n_windows, n_indicators * 3)
        cloud-feature matrix interleaved as [Ex, En, He].
    """
    values = np.asarray(values, dtype=float)
    n_w, n_ind, _ = values.shape
    out = np.empty((n_w, n_ind * 3), dtype=float)
    for i in range(n_w):
        for j in range(n_ind):
            ex, en, he = reverse_cloud(values[i, j])
            out[i, 3 * j: 3 * j + 3] = (ex, en, he)
    return out


def he_diagnostics(values: np.ndarray, indicator_names: list[str]) -> "object":
    """Diagnostics of the He distribution: quantiles, zero frequency, and the En/S ratio.

    values : (n_windows, n_indicators, T)
    """
    import pandas as pd

    values = np.asarray(values, dtype=float)
    rows = []
    for j, name in enumerate(indicator_names):
        he, en_over_s = [], []
        for i in range(values.shape[0]):
            ex, e, h = reverse_cloud(values[i, j])
            if np.isnan(h):
                continue
            he.append(h)
            s = np.nanstd(values[i, j], ddof=1)
            en_over_s.append(e / s if s > 0 else np.nan)
        he = np.asarray(he)
        rows.append({
            "indicator": name,
            "n_windows": he.size,
            "he_zero_share": float(np.mean(he <= 0)),
            "he_p05": float(np.nanpercentile(he, 5)),
            "he_p25": float(np.nanpercentile(he, 25)),
            "he_median": float(np.nanmedian(he)),
            "he_p75": float(np.nanpercentile(he, 75)),
            "he_p95": float(np.nanpercentile(he, 95)),
            "en_over_sd_median": float(np.nanmedian(en_over_s)),
        })
    return pd.DataFrame(rows)


def window_length_sensitivity(values: np.ndarray, indicator_names: list[str],
                              lengths=(4, 6, 8, 10, 12)) -> "object":
    """Window-length sensitivity: zero frequency and median of He under different window lengths (last L quarters per window)."""
    import pandas as pd

    values = np.asarray(values, dtype=float)
    rows = []
    for L in lengths:
        if L > values.shape[2]:
            continue
        sub = values[:, :, -L:]
        he_all = []
        for j in range(sub.shape[1]):
            for i in range(sub.shape[0]):
                _, _, h = reverse_cloud(sub[i, j])
                if not np.isnan(h):
                    he_all.append(h)
        he_all = np.asarray(he_all)
        rows.append({
            "window_length": L,
            "he_zero_share": float(np.mean(he_all <= 0)),
            "he_median": float(np.nanmedian(he_all)),
            "he_p95": float(np.nanpercentile(he_all, 95)),
        })
    return pd.DataFrame(rows)


def attention_event_alignment(attn: np.ndarray, event_quarter_idx: np.ndarray,
                              window_quarters: np.ndarray, tol: int = 1) -> float:
    """Attention-event alignment: whether the top-2 attention time steps fall within +/- tol quarters of the label-event quarter.

    attn               : (n_windows, T) attention weights
    event_quarter_idx  : (n_windows,) relative position of the label-event quarter within the window; -1 if no event
    window_quarters    : (n_windows, T) absolute quarter index of each window time step
    """
    hit, n = 0, 0
    for i in range(attn.shape[0]):
        if event_quarter_idx[i] < 0:
            continue
        n += 1
        top2 = np.argsort(-attn[i])[:2]
        if np.any(np.abs(top2 - event_quarter_idx[i]) <= tol):
            hit += 1
    return hit / n if n else np.nan
