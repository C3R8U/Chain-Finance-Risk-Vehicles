# -*- coding: utf-8 -*-
"""Table aggregation entry point.

Table generation is unified: ``compute_numbers.py`` is the single source of
truth for all manuscript tables/statistics (it writes
``04_outputs/numbers.json`` and every CSV in ``04_outputs/tables/``). This
script is kept only as a thin wrapper so that legacy calls
(``python make_tables.py``) keep working.

Usage:
    python make_tables.py            # delegate to compute_numbers.py
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main() -> int:
    cmd = [sys.executable, str(HERE / "compute_numbers.py")]
    print(">>> " + " ".join(cmd))
    r = subprocess.run(cmd, cwd=str(HERE))
    if r.returncode != 0:
        print(f"compute_numbers.py failed with exit code {r.returncode}",
              file=sys.stderr)
    return r.returncode


if __name__ == "__main__":
    raise SystemExit(main())
