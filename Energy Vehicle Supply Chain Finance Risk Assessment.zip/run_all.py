# -*- coding: utf-8 -*-
"""Pipeline controller with two clearly separated data/evidence modes.

Default: verified official source evidence required, then *new* training.
Archived snapshot audit: `python run_all.py --audit-snapshot`.
A source gate must fail if candidates have not been fully adjudicated.
"""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def run(*parts):
    command=[sys.executable,*parts]
    print('>',' '.join(command),flush=True)
    subprocess.run(command,cwd=ROOT,check=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--audit-snapshot',action='store_true',help='Recalculate archived statistics; no new model training')
    ap.add_argument('--data-mode',choices=['verified','legacy'],default='verified')
    ap.add_argument('--stage',choices=['main','ablation','both'],default='both')
    ap.add_argument('--skip-figures',action='store_true')
    args=ap.parse_args()
    if args.audit_snapshot:
        cmd=['run_checks.py']+(['--no-fig'] if args.skip_figures else [])
        run(*cmd)
        run('-m','unittest','discover','-s','tests','-p','test_*.py','-v')
        print('Archived numerical snapshot checked; official source evidence remains independent.')
        return
    run('01_data/source_audit.py','--require-complete') if args.data_mode=='verified' else None
    run('01_data/build_data.py','--label-mode',args.data_mode)
    stages=['main','ablation'] if args.stage=='both' else [args.stage]
    for stage in stages:
        run('02_code/train.py','--data-mode',args.data_mode,'--stage',stage)
    run('02_code/compile_retrained.py','--data-mode',args.data_mode)
    if not args.skip_figures:
        run('03_figures/plot_retrained.py','--data-mode',args.data_mode)
    print('Training outputs are in 04_outputs/retrained and DO NOT overwrite the archived snapshot.')

if __name__=='__main__':
    main()
